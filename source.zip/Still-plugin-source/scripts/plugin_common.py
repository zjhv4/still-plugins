"""Shared manifest loading and plugin path validation."""

from pathlib import Path
import re
import tomllib

ROOT = Path(__file__).resolve().parents[1]
PLUGINS = ROOT / "plugins"
PLUGIN_NAME = re.compile(r"[a-z][a-z0-9]*(?:-[a-z0-9]+)*")
PLUGIN_ID = re.compile(r"org\.wallpaper\.(?:source|processor)\.[a-z][a-z0-9]*(?:-[a-z0-9]+)*")


def load(path: Path) -> dict:
    with path.open("rb") as handle:
        return tomllib.load(handle)


def plugin_directory(name: str) -> Path:
    if not PLUGIN_NAME.fullmatch(name):
        raise SystemExit(f"invalid plugin name: {name}")
    directory = PLUGINS / name
    if directory.is_symlink() or not (directory / "Cargo.toml").is_file():
        raise SystemExit(f"unknown plugin: {name}")
    return directory
