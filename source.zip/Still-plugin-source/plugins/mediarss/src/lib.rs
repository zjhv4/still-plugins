use std::collections::BTreeMap;

use chrono::{DateTime, Utc};
use quick_xml::Reader;
use quick_xml::events::Event;
use url::Url;
use wallpaper_plugin_sdk::paginate_items;
use wallpaper_plugin_sdk::{
    Author, CardConfigItem, CardFieldWidth, ConfigField, ConfigFieldKind, ConfigSchema,
    ConfigUiSchema, ContentRating, HostHttpRequest, HostHttpResponse, HttpMethod, NetworkScope,
    PluginError, PluginManifest, SourceCapabilities, SourcePlugin, SourceRequest, WallpaperItem,
    WallpaperPage, WallpaperVariant,
};

#[derive(Debug, Default)]
pub struct MediaRssPlugin;

#[cfg(target_arch = "wasm32")]
wallpaper_plugin_sdk::export_source_plugin!(MediaRssPlugin);

impl SourcePlugin for MediaRssPlugin {
    fn manifest(&self) -> PluginManifest {
        PluginManifest::new(
            "org.wallpaper.source.mediarss",
            "MediaRSS",
            env!("CARGO_PKG_VERSION"),
            "Wallpaper contributors",
            "Read images from any compatible Media RSS feed",
            Vec::<String>::new(),
        )
    }

    fn config_schema(&self) -> ConfigSchema {
        ConfigSchema {
            version: 1,
            fields: vec![ConfigField {
                key: "feed_url".into(),
                label: "Feed URL".into(),
                description: Some("HTTPS Media RSS feed address".into()),
                required: true,
                sensitive: false,
                kind: ConfigFieldKind::Url { default: None },
            }],
        }
    }

    fn config_ui_schema(&self) -> ConfigUiSchema {
        ConfigUiSchema {
            card: vec![CardConfigItem::new("feed_url", CardFieldWidth::Full)],
        }
    }

    fn capabilities(&self) -> SourceCapabilities {
        SourceCapabilities {
            list: true,
            ..Default::default()
        }
    }

    fn validate_config(
        &self,
        config: &BTreeMap<String, serde_json::Value>,
    ) -> Result<(), PluginError> {
        feed_url(config).map(|_| ())
    }

    fn build_list_request(&self, request: &SourceRequest) -> Result<HostHttpRequest, PluginError> {
        let url = feed_url(&request.config)?;
        if url.scheme() != "https" {
            return Err(PluginError::InvalidConfig("feed_url must use HTTPS".into()));
        }
        Ok(HostHttpRequest {
            method: HttpMethod::Get,
            url,
            headers: BTreeMap::from([(
                "Accept".into(),
                "application/rss+xml, application/xml, text/xml".into(),
            )]),
            form_fields: BTreeMap::new(),
            max_response_bytes: 4 * 1024 * 1024,
            network_scope: NetworkScope::ConfiguredUrl {
                config_key: "feed_url".into(),
            },
            credential_injections: Vec::new(),
        })
    }

    fn parse_list_response(
        &self,
        request: &SourceRequest,
        response: HostHttpResponse,
    ) -> Result<WallpaperPage, PluginError> {
        if !(200..300).contains(&response.status) {
            return Err(PluginError::HttpStatus(response.status));
        }
        let feed = feed_url(&request.config)?;
        let page = parse_feed(&response.body, &feed, usize::MAX)?;
        paginate_items(page.items, request)
    }
}

#[derive(Debug, Default)]
struct PendingItem {
    id: Option<String>,
    title: Option<String>,
    description: Option<String>,
    link: Option<String>,
    author: Option<String>,
    published_at: Option<DateTime<Utc>>,
    content_urls: Vec<PendingVariant>,
}

#[derive(Debug)]
struct PendingVariant {
    url: String,
    mime_type: Option<String>,
    width: Option<u32>,
    height: Option<u32>,
}

pub fn parse_feed(body: &[u8], feed_url: &Url, limit: usize) -> Result<WallpaperPage, PluginError> {
    if body.len() > 4 * 1024 * 1024 {
        return Err(PluginError::InvalidResponse("feed exceeds 4 MiB".into()));
    }
    let mut reader = Reader::from_reader(body);
    reader.config_mut().trim_text(true);
    let mut items = Vec::new();
    let mut current: Option<PendingItem> = None;
    let mut text_target: Option<Vec<u8>> = None;
    let mut text_buffer = String::new();

    loop {
        match reader.read_event() {
            Ok(Event::Start(event)) => {
                let name = event.name().as_ref().to_vec();
                if name.as_slice() == b"item" || name.as_slice() == b"entry" {
                    current = Some(PendingItem::default());
                } else if current.is_some() {
                    text_target = Some(name.clone());
                    text_buffer.clear();
                    if is_media_element(&name) {
                        let mut url = None;
                        let mut mime = None;
                        let mut width = None;
                        let mut height = None;
                        for attribute in event.attributes().flatten() {
                            let value =
                                String::from_utf8_lossy(attribute.value.as_ref()).into_owned();
                            match attribute.key.as_ref() {
                                b"url" | b"href" => url = Some(value),
                                b"type" => mime = Some(value),
                                b"width" => width = value.parse().ok(),
                                b"height" => height = value.parse().ok(),
                                _ => {}
                            }
                        }
                        if let Some(url) = url {
                            current.as_mut().unwrap().content_urls.push(PendingVariant {
                                url,
                                mime_type: mime,
                                width,
                                height,
                            });
                        }
                    }
                }
            }
            Ok(Event::Empty(event)) if current.is_some() => {
                let name = event.name().as_ref().to_vec();
                if is_media_element(&name) {
                    let mut url = None;
                    let mut mime = None;
                    let mut width = None;
                    let mut height = None;
                    for attribute in event.attributes().flatten() {
                        let value = String::from_utf8_lossy(attribute.value.as_ref()).into_owned();
                        match attribute.key.as_ref() {
                            b"url" | b"href" => url = Some(value),
                            b"type" => mime = Some(value),
                            b"width" => width = value.parse().ok(),
                            b"height" => height = value.parse().ok(),
                            _ => {}
                        }
                    }
                    if let Some(url) = url {
                        current.as_mut().unwrap().content_urls.push(PendingVariant {
                            url,
                            mime_type: mime,
                            width,
                            height,
                        });
                    }
                }
            }
            Ok(Event::Text(text)) if current.is_some() => {
                text_buffer.push_str(&String::from_utf8_lossy(text.as_ref()));
            }
            Ok(Event::CData(text)) if current.is_some() => {
                text_buffer.push_str(&String::from_utf8_lossy(text.as_ref()));
            }
            Ok(Event::GeneralRef(reference)) if current.is_some() => {
                text_buffer.push('&');
                text_buffer.push_str(&String::from_utf8_lossy(reference.as_ref()));
                text_buffer.push(';');
            }
            Ok(Event::End(event)) => {
                let name = event.name().as_ref().to_vec();
                if text_target.as_deref() == Some(name.as_slice()) {
                    let value = quick_xml::escape::unescape(&text_buffer)
                        .map(|value| value.into_owned())
                        .unwrap_or_else(|_| text_buffer.clone());
                    let value = value.trim().to_owned();
                    if !value.is_empty() {
                        apply_text(current.as_mut().unwrap(), text_target.as_deref(), value);
                    }
                    text_buffer.clear();
                    text_target = None;
                }
                if (name.as_slice() == b"item" || name.as_slice() == b"entry")
                    && let Some(pending) = current.take()
                    && let Some(item) = finish_item(pending, feed_url)
                {
                    items.push(item);
                    if items.len() >= limit.max(1) {
                        break;
                    }
                }
            }
            Ok(Event::Eof) => break,
            Err(error) => return Err(PluginError::InvalidResponse(error.to_string())),
            _ => {}
        }
    }

    Ok(WallpaperPage {
        items,
        next_cursor: None,
    })
}

fn apply_text(item: &mut PendingItem, target: Option<&[u8]>, value: String) {
    match target {
        Some(b"guid" | b"id") => item.id = Some(value),
        Some(b"title") => item.title = Some(value),
        Some(b"description" | b"summary" | b"content" | b"content:encoded") => {
            for url in image_urls_from_markup(&value) {
                if !item.content_urls.iter().any(|variant| variant.url == url) {
                    item.content_urls.push(PendingVariant {
                        url,
                        mime_type: None,
                        width: None,
                        height: None,
                    });
                }
            }
            if !value.contains('<') {
                item.description = Some(value);
            }
        }
        Some(b"link") => item.link = Some(value),
        Some(b"author" | b"dc:creator") => item.author = Some(value),
        Some(b"pubDate" | b"published" | b"updated") => {
            item.published_at = DateTime::parse_from_rfc2822(&value)
                .or_else(|_| DateTime::parse_from_rfc3339(&value))
                .map(|date| date.with_timezone(&Utc))
                .ok();
        }
        _ => {}
    }
}

fn image_urls_from_markup(markup: &str) -> Vec<String> {
    let decoded = quick_xml::escape::unescape(markup)
        .map(|value| value.into_owned())
        .unwrap_or_else(|_| markup.to_owned());
    let mut urls = Vec::new();
    for attribute in ["src", "href", "srcset"] {
        let mut remainder = decoded.as_str();
        let needle = format!("{attribute}=\"");
        while let Some(start) = remainder.find(&needle) {
            remainder = &remainder[start + needle.len()..];
            let Some(end) = remainder.find('"') else {
                break;
            };
            let value = &remainder[..end];
            let candidates: Vec<&str> = if attribute == "srcset" {
                value
                    .split(',')
                    .filter_map(|candidate| candidate.split_whitespace().next())
                    .collect()
            } else {
                vec![value]
            };
            for candidate in candidates {
                if is_probable_image_url(candidate)
                    && !urls.iter().any(|existing| existing == candidate)
                {
                    urls.push(candidate.to_owned());
                }
            }
            remainder = &remainder[end + 1..];
        }
    }
    let mut remainder = decoded.as_str();
    while let Some(start) = remainder.find("https://") {
        remainder = &remainder[start..];
        let end = remainder
            .find(|character: char| {
                character.is_whitespace() || matches!(character, '"' | '\'' | '<' | '>')
            })
            .unwrap_or(remainder.len());
        let candidate = remainder[..end].replace("&amp;", "&");
        if is_probable_image_url(&candidate) && !urls.iter().any(|existing| existing == &candidate)
        {
            urls.push(candidate);
        }
        remainder = &remainder[end.min(remainder.len())..];
        if remainder.starts_with("https://") {
            remainder = &remainder[8..];
        }
    }
    urls
}

fn is_probable_image_url(value: &str) -> bool {
    Url::parse(value).is_ok_and(|url| {
        url.scheme() == "https"
            && matches!(
                url.path()
                    .rsplit('.')
                    .next()
                    .map(str::to_ascii_lowercase)
                    .as_deref(),
                Some("jpg" | "jpeg" | "png" | "webp")
            )
    })
}

fn finish_item(item: PendingItem, feed_url: &Url) -> Option<WallpaperItem> {
    let source_page_url = item
        .link
        .as_deref()
        .and_then(|value| feed_url.join(value).ok())
        .unwrap_or_else(|| feed_url.clone());
    let mut variants: Vec<_> = item
        .content_urls
        .into_iter()
        .filter_map(|variant| {
            feed_url
                .join(&variant.url)
                .ok()
                .map(|url| WallpaperVariant {
                    url,
                    mime_type: variant.mime_type,
                    width: variant.width,
                    height: variant.height,
                    file_size: None,
                    checksum: None,
                })
        })
        .collect();
    variants.sort_by_key(|variant| {
        std::cmp::Reverse(
            variant
                .width
                .or_else(|| inferred_pixel_width(&variant.url))
                .unwrap_or(0),
        )
    });
    if variants.is_empty() {
        return None;
    }
    let id = item
        .id
        .unwrap_or_else(|| variants[0].url.as_str().to_owned());
    Some(WallpaperItem {
        id,
        title: item.title,
        description: item.description,
        author: item.author.map(|name| Author { name, url: None }),
        source_page_url,
        license: None,
        attribution: None,
        published_at: item.published_at,
        tags: Vec::new(),
        content_rating: ContentRating::Unknown,
        location: None,
        variants,
        metadata: BTreeMap::new(),
    })
}

fn inferred_pixel_width(url: &Url) -> Option<u32> {
    url.path_segments()?.find_map(|segment| {
        let (width, _) = segment.split_once("px-")?;
        width.parse().ok()
    })
}

fn is_media_element(name: &[u8]) -> bool {
    matches!(name, b"media:content" | b"media:thumbnail" | b"enclosure")
}

fn feed_url(config: &BTreeMap<String, serde_json::Value>) -> Result<Url, PluginError> {
    let value = config
        .get("feed_url")
        .and_then(serde_json::Value::as_str)
        .ok_or_else(|| PluginError::InvalidConfig("feed_url is required".into()))?;
    Url::parse(value).map_err(|error| PluginError::InvalidConfig(error.to_string()))
}

#[cfg(test)]
mod tests {
    use super::*;

    const FEED: &[u8] = include_bytes!("../tests/fixtures/list.xml");

    fn request() -> SourceRequest {
        SourceRequest {
            context: Default::default(),
            config: BTreeMap::from([(
                "feed_url".into(),
                serde_json::json!("https://example.com/feed.xml"),
            )]),
            query: None,
            cursor: None,
            limit: 20,
        }
    }

    #[test]
    fn parses_media_rss_item() {
        let plugin = MediaRssPlugin;
        let page = plugin
            .parse_list_response(
                &request(),
                HostHttpResponse {
                    status: 200,
                    content_type: Some("application/rss+xml".into()),
                    body: FEED.to_vec(),
                },
            )
            .unwrap();

        assert_eq!(page.items.len(), 1);
        assert_eq!(page.items[0].id, "mountain-1");
        assert_eq!(page.items[0].author.as_ref().unwrap().name, "Ada");
        assert_eq!(page.items[0].variants[0].width, Some(1920));
    }

    #[test]
    fn rejects_insecure_feed_url() {
        let mut request = request();
        request.config.insert(
            "feed_url".into(),
            serde_json::json!("http://example.com/feed.xml"),
        );

        assert!(MediaRssPlugin.build_list_request(&request).is_err());
    }

    #[test]
    fn handles_empty_feed_and_http_error() {
        let plugin = MediaRssPlugin;
        let empty = plugin
            .parse_list_response(
                &request(),
                HostHttpResponse {
                    status: 200,
                    content_type: Some("application/rss+xml".into()),
                    body: b"<rss><channel></channel></rss>".to_vec(),
                },
            )
            .unwrap();
        assert!(empty.items.is_empty());
        assert!(matches!(
            plugin.parse_list_response(
                &request(),
                HostHttpResponse {
                    status: 503,
                    content_type: None,
                    body: Vec::new(),
                }
            ),
            Err(PluginError::HttpStatus(503))
        ));
    }

    #[test]
    fn extracts_images_from_escaped_html_feeds() {
        let feed = br#"<?xml version="1.0"?><rss><channel><item>
            <title>Picture</title><link>https://example.com/picture</link>
            <description>&lt;img src=&quot;https://images.example.com/photo.jpg?x=1&amp;amp;y=2&quot; /&gt;</description>
            </item></channel></rss>"#;
        let page = parse_feed(
            feed,
            &Url::parse("https://example.com/feed.xml").unwrap(),
            1,
        )
        .unwrap();
        assert_eq!(page.items.len(), 1);
        assert_eq!(
            page.items[0].variants[0].url.as_str(),
            "https://images.example.com/photo.jpg?x=1&y=2"
        );
    }
}
