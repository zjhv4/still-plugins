use std::collections::BTreeMap;

use chrono::{DateTime, Utc};
use serde::{Deserialize, Deserializer};
use url::Url;
use wallpaper_plugin_sdk::{
    Author, CardConfigItem, CardFieldWidth, ConfigField, ConfigFieldKind, ConfigSchema,
    ConfigUiSchema, ContentRating, CredentialInjection, CredentialTarget, HostHttpRequest,
    HostHttpResponse, HttpMethod, NetworkPolicy, NetworkScope, PluginError, PluginManifest,
    SelectOption, SourceCapabilities, SourcePlugin, SourceRequest, WallpaperItem, WallpaperPage,
    WallpaperVariant, ensure_success, page_number,
};

#[derive(Debug, Default)]
pub struct WallhavenPlugin;

#[cfg(target_arch = "wasm32")]
wallpaper_plugin_sdk::export_source_plugin!(WallhavenPlugin);

impl SourcePlugin for WallhavenPlugin {
    fn manifest(&self) -> PluginManifest {
        let mut manifest = PluginManifest::new(
            "org.wallpaper.source.wallhaven",
            "Wallhaven",
            env!("CARGO_PKG_VERSION"),
            "Wallpaper contributors",
            "Search Wallhaven with explicit category, purity and resolution filters",
            ["wallhaven.cc", "w.wallhaven.cc", "th.wallhaven.cc"],
        );
        manifest.documentation_url = Url::parse("https://wallhaven.cc/help/api").ok();
        manifest.network = NetworkPolicy {
            requests_per_minute: 45,
            max_concurrent_requests: 2,
            timeout_seconds: 20,
            max_retries: 2,
        };
        manifest
    }

    fn config_schema(&self) -> ConfigSchema {
        ConfigSchema {
            version: 1,
            fields: vec![
                text("query", "Search query", Some("landscape")),
                select(
                    "sorting",
                    "Sorting",
                    &[
                        ("toplist", "Top"),
                        ("date_added", "Latest"),
                        ("random", "Random"),
                    ],
                ),
                select(
                    "categories",
                    "Categories",
                    &[
                        ("111", "All"),
                        ("100", "General"),
                        ("010", "Anime"),
                        ("001", "People"),
                    ],
                ),
                select(
                    "purity",
                    "Purity",
                    &[("100", "Safe"), ("110", "Safe + Sketchy"), ("111", "All")],
                ),
                text("atleast", "Minimum resolution", Some("1920x1080")),
                ConfigField {
                    key: "api_key".into(),
                    label: "API key".into(),
                    description: Some(
                        "Required for NSFW results; stored as a secret reference".into(),
                    ),
                    required: false,
                    sensitive: true,
                    kind: ConfigFieldKind::SecretReference,
                },
            ],
        }
    }

    fn config_ui_schema(&self) -> ConfigUiSchema {
        ConfigUiSchema {
            card: vec![
                CardConfigItem::new("query", CardFieldWidth::Full),
                CardConfigItem::new("sorting", CardFieldWidth::Half),
                CardConfigItem::new("categories", CardFieldWidth::Half),
                CardConfigItem::new("purity", CardFieldWidth::Half),
                CardConfigItem::new("atleast", CardFieldWidth::Half),
                CardConfigItem::new("api_key", CardFieldWidth::Full),
            ],
        }
    }

    fn capabilities(&self) -> SourceCapabilities {
        SourceCapabilities {
            list: true,
            search: true,
            random: true,
            ..Default::default()
        }
    }

    fn validate_config(
        &self,
        config: &BTreeMap<String, serde_json::Value>,
    ) -> Result<(), PluginError> {
        let purity = value(config, "purity", "100");
        if !matches!(purity, "100" | "110" | "111") {
            return Err(PluginError::InvalidConfig("invalid purity mask".into()));
        }
        let categories = value(config, "categories", "111");
        if categories.len() != 3 || !categories.bytes().all(|byte| matches!(byte, b'0' | b'1')) {
            return Err(PluginError::InvalidConfig("invalid category mask".into()));
        }
        Ok(())
    }

    fn build_list_request(&self, request: &SourceRequest) -> Result<HostHttpRequest, PluginError> {
        self.build_request(request, request.query.as_deref())
    }

    fn parse_list_response(
        &self,
        request: &SourceRequest,
        response: HostHttpResponse,
    ) -> Result<WallpaperPage, PluginError> {
        parse_response(request, response)
    }

    fn build_search_request(
        &self,
        request: &SourceRequest,
    ) -> Result<HostHttpRequest, PluginError> {
        self.build_request(request, request.query.as_deref())
    }

    fn parse_search_response(
        &self,
        request: &SourceRequest,
        response: HostHttpResponse,
    ) -> Result<WallpaperPage, PluginError> {
        parse_response(request, response)
    }

    fn build_random_request(
        &self,
        request: &SourceRequest,
    ) -> Result<HostHttpRequest, PluginError> {
        let mut config = request.config.clone();
        config.insert("sorting".into(), serde_json::json!("random"));
        self.build_request(
            &SourceRequest {
                config,
                ..request.clone()
            },
            request.query.as_deref(),
        )
    }

    fn parse_random_response(
        &self,
        request: &SourceRequest,
        response: HostHttpResponse,
    ) -> Result<WallpaperPage, PluginError> {
        parse_response(request, response)
    }
}

impl WallhavenPlugin {
    fn build_request(
        &self,
        request: &SourceRequest,
        query_override: Option<&str>,
    ) -> Result<HostHttpRequest, PluginError> {
        self.validate_config(&request.config)?;
        let page = page_number(request.cursor.as_deref())?;
        let mut url = Url::parse("https://wallhaven.cc/api/v1/search").unwrap();
        let query = query_override.unwrap_or_else(|| value(&request.config, "query", ""));
        url.query_pairs_mut()
            .append_pair("q", query)
            .append_pair("sorting", value(&request.config, "sorting", "toplist"))
            .append_pair("categories", value(&request.config, "categories", "111"))
            .append_pair("purity", value(&request.config, "purity", "100"))
            .append_pair("atleast", value(&request.config, "atleast", "1920x1080"))
            .append_pair("page", &page.to_string());
        Ok(HostHttpRequest {
            method: HttpMethod::Get,
            url,
            headers: BTreeMap::from([("Accept".into(), "application/json".into())]),
            form_fields: BTreeMap::new(),
            max_response_bytes: 4 * 1024 * 1024,
            network_scope: NetworkScope::DeclaredHost,
            credential_injections: vec![CredentialInjection {
                config_key: "api_key".into(),
                target: CredentialTarget::Header {
                    name: "X-API-Key".into(),
                    prefix: String::new(),
                },
                required: false,
            }],
        })
    }
}

#[derive(Debug, Deserialize)]
struct SearchResponse {
    data: Vec<WallhavenEntry>,
    meta: SearchMeta,
}

#[derive(Debug, Deserialize)]
struct SearchMeta {
    current_page: u32,
    last_page: u32,
}

#[derive(Debug, Deserialize)]
struct WallhavenEntry {
    id: String,
    url: Url,
    path: Url,
    dimension_x: u32,
    dimension_y: u32,
    file_size: u64,
    file_type: String,
    purity: String,
    category: String,
    #[serde(default, deserialize_with = "deserialize_wallhaven_time")]
    created_at: Option<DateTime<Utc>>,
    #[serde(default)]
    uploader: Option<Uploader>,
    #[serde(default)]
    tags: Vec<Tag>,
}

fn deserialize_wallhaven_time<'de, D>(deserializer: D) -> Result<Option<DateTime<Utc>>, D::Error>
where
    D: Deserializer<'de>,
{
    let value = Option::<String>::deserialize(deserializer)?;
    value
        .map(|value| {
            DateTime::parse_from_rfc3339(&value)
                .map(|date| date.with_timezone(&Utc))
                .or_else(|_| {
                    chrono::NaiveDateTime::parse_from_str(&value, "%Y-%m-%d %H:%M:%S")
                        .map(|date| date.and_utc())
                })
                .map_err(serde::de::Error::custom)
        })
        .transpose()
}

#[derive(Debug, Deserialize)]
struct Uploader {
    username: String,
}

#[derive(Debug, Deserialize)]
struct Tag {
    name: String,
}

fn parse_response(
    request: &SourceRequest,
    response: HostHttpResponse,
) -> Result<WallpaperPage, PluginError> {
    ensure_success(&response)?;
    let payload: SearchResponse = serde_json::from_slice(&response.body)
        .map_err(|error| PluginError::InvalidResponse(error.to_string()))?;
    let next_cursor = (payload.meta.current_page < payload.meta.last_page)
        .then(|| (payload.meta.current_page + 1).to_string());
    let items = payload
        .data
        .into_iter()
        .take(usize::from(request.limit.max(1)))
        .map(|entry| WallpaperItem {
            id: entry.id,
            title: entry.tags.first().map(|tag| tag.name.clone()),
            description: Some(entry.category),
            author: entry.uploader.map(|uploader| Author {
                name: uploader.username,
                url: None,
            }),
            source_page_url: entry.url,
            license: None,
            attribution: Some("Source: Wallhaven".into()),
            published_at: entry.created_at,
            tags: entry.tags.into_iter().map(|tag| tag.name).collect(),
            content_rating: match entry.purity.as_str() {
                "sfw" => ContentRating::Safe,
                "sketchy" => ContentRating::Sketchy,
                "nsfw" => ContentRating::Adult,
                _ => ContentRating::Unknown,
            },
            location: None,
            variants: vec![WallpaperVariant {
                url: entry.path,
                mime_type: Some(entry.file_type),
                width: Some(entry.dimension_x),
                height: Some(entry.dimension_y),
                file_size: Some(entry.file_size),
                checksum: None,
            }],
            metadata: BTreeMap::new(),
        })
        .collect();
    Ok(WallpaperPage { items, next_cursor })
}

fn value<'a>(
    config: &'a BTreeMap<String, serde_json::Value>,
    key: &str,
    default: &'a str,
) -> &'a str {
    config
        .get(key)
        .and_then(serde_json::Value::as_str)
        .unwrap_or(default)
}

fn text(key: &str, label: &str, default: Option<&str>) -> ConfigField {
    ConfigField {
        key: key.into(),
        label: label.into(),
        description: None,
        required: false,
        sensitive: false,
        kind: ConfigFieldKind::Text {
            default: default.map(Into::into),
        },
    }
}

fn select(key: &str, label: &str, values: &[(&str, &str)]) -> ConfigField {
    ConfigField {
        key: key.into(),
        label: label.into(),
        description: None,
        required: true,
        sensitive: false,
        kind: ConfigFieldKind::Select {
            options: values
                .iter()
                .map(|(value, label)| SelectOption {
                    value: (*value).into(),
                    label: (*label).into(),
                })
                .collect(),
        },
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn request() -> SourceRequest {
        SourceRequest {
            context: Default::default(),
            config: BTreeMap::new(),
            query: Some("mountains".into()),
            cursor: None,
            limit: 24,
        }
    }

    #[test]
    fn parses_pagination_rating_and_dimensions() {
        let body = include_bytes!("../tests/fixtures/list.json");
        let page = WallhavenPlugin
            .parse_list_response(
                &request(),
                HostHttpResponse {
                    status: 200,
                    content_type: Some("application/json".into()),
                    body: body.to_vec(),
                },
            )
            .unwrap();
        assert_eq!(page.next_cursor.as_deref(), Some("2"));
        assert_eq!(page.items[0].content_rating, ContentRating::Safe);
        assert_eq!(page.items[0].variants[0].width, Some(3840));
    }

    #[test]
    fn handles_empty_page_and_http_error() {
        let empty = WallhavenPlugin
            .parse_list_response(
                &request(),
                HostHttpResponse {
                    status: 200,
                    content_type: Some("application/json".into()),
                    body: br#"{"data":[],"meta":{"current_page":1,"last_page":1}}"#.to_vec(),
                },
            )
            .unwrap();
        assert!(empty.items.is_empty());
        assert!(matches!(
            WallhavenPlugin.parse_list_response(
                &request(),
                HostHttpResponse {
                    status: 429,
                    content_type: None,
                    body: Vec::new(),
                }
            ),
            Err(PluginError::HttpStatus(429))
        ));
    }
}
