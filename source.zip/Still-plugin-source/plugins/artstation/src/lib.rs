use std::collections::BTreeMap;

use chrono::{DateTime, Utc};
use serde::Deserialize;
use url::Url;
use wallpaper_plugin_sdk::paginate_items;
use wallpaper_plugin_sdk::{
    Author, CardConfigItem, CardFieldWidth, ConfigField, ConfigFieldKind, ConfigSchema,
    ConfigUiSchema, ContentRating, HostHttpRequest, HostHttpResponse, HttpMethod, NetworkPolicy,
    NetworkScope, PluginError, PluginManifest, SourceCapabilities, SourcePlugin, SourceRequest,
    WallpaperItem, WallpaperPage, WallpaperVariant, ensure_success,
};

#[derive(Debug, Default)]
pub struct ArtStationPlugin;

#[cfg(target_arch = "wasm32")]
wallpaper_plugin_sdk::export_source_plugin!(ArtStationPlugin);

impl SourcePlugin for ArtStationPlugin {
    fn manifest(&self) -> PluginManifest {
        let mut manifest = PluginManifest::new(
            "org.wallpaper.source.artstation",
            "ArtStation",
            env!("CARGO_PKG_VERSION"),
            "Wallpaper contributors",
            "ArtStation artist portfolio adapter using the public first-party JSON feed",
            Vec::<String>::new(),
        );
        manifest.documentation_url = Url::parse("https://www.artstation.com/tos").ok();
        manifest.network = NetworkPolicy {
            requests_per_minute: 6,
            max_concurrent_requests: 1,
            timeout_seconds: 20,
            max_retries: 1,
        };
        manifest
    }

    fn config_schema(&self) -> ConfigSchema {
        ConfigSchema {
            version: 2,
            fields: vec![
                ConfigField {
                    key: "artist".into(),
                    label: "Artist username or portfolio URL".into(),
                    description: Some(
                        "Uses https://USERNAME.artstation.com/projects.json; pages are not scraped"
                            .into(),
                    ),
                    required: true,
                    sensitive: false,
                    kind: ConfigFieldKind::Text { default: None },
                },
                ConfigField {
                    key: "allow_nsfw".into(),
                    label: "Allow adult projects".into(),
                    description: Some("Disabled by default".into()),
                    required: false,
                    sensitive: false,
                    kind: ConfigFieldKind::Toggle { default: false },
                },
            ],
        }
    }

    fn config_ui_schema(&self) -> ConfigUiSchema {
        ConfigUiSchema {
            card: vec![
                CardConfigItem::new("artist", CardFieldWidth::Full),
                CardConfigItem::new("allow_nsfw", CardFieldWidth::Full),
            ],
        }
    }

    fn capabilities(&self) -> SourceCapabilities {
        SourceCapabilities {
            list: true,
            ..Default::default()
        }
    }

    fn validate_config(
        &self,
        config: &BTreeMap<String, serde_json::Value>,
    ) -> Result<(), PluginError> {
        artstation_projects_url(config).map(|_| ())
    }

    fn migrate_config(
        &self,
        from_version: u32,
        mut config: BTreeMap<String, serde_json::Value>,
    ) -> Result<BTreeMap<String, serde_json::Value>, PluginError> {
        if from_version == 1 {
            config
                .entry("allow_nsfw".into())
                .or_insert(serde_json::Value::Bool(false));
            self.validate_config(&config)?;
            Ok(config)
        } else if from_version == 2 {
            self.validate_config(&config)?;
            Ok(config)
        } else {
            Err(PluginError::UnsupportedConfigVersion(from_version))
        }
    }

    fn build_list_request(&self, request: &SourceRequest) -> Result<HostHttpRequest, PluginError> {
        let url = artstation_projects_url(&request.config)?;
        Ok(HostHttpRequest {
            method: HttpMethod::Get,
            url,
            headers: BTreeMap::from([
                ("Accept".into(), "application/json".into()),
                (
                    "User-Agent".into(),
                    format!("Wallpaper/{} source plugin", env!("CARGO_PKG_VERSION")),
                ),
            ]),
            form_fields: BTreeMap::new(),
            max_response_bytes: 8 * 1024 * 1024,
            network_scope: NetworkScope::SubdomainOf {
                parent: "artstation.com".into(),
            },
            credential_injections: Vec::new(),
        })
    }

    fn parse_list_response(
        &self,
        request: &SourceRequest,
        response: HostHttpResponse,
    ) -> Result<WallpaperPage, PluginError> {
        ensure_success(&response)?;
        let payload: ProjectsPayload = serde_json::from_slice(&response.body)
            .map_err(|error| PluginError::InvalidResponse(error.to_string()))?;
        let allow_nsfw = request
            .config
            .get("allow_nsfw")
            .and_then(serde_json::Value::as_bool)
            .unwrap_or(false);
        let items = payload
            .data
            .into_iter()
            .filter(|project| allow_nsfw || !project.hide_as_adult)
            .filter_map(Project::into_item)
            .collect();
        paginate_items(items, request)
    }
}

#[derive(Debug, Deserialize)]
struct ProjectsPayload {
    data: Vec<Project>,
}

#[derive(Debug, Deserialize)]
struct Project {
    id: u64,
    hash_id: String,
    title: String,
    #[serde(default)]
    description: Option<String>,
    permalink: Url,
    #[serde(default)]
    published_at: Option<DateTime<Utc>>,
    #[serde(default)]
    hide_as_adult: bool,
    user: ProjectUser,
    #[serde(default)]
    assets: Vec<ProjectAsset>,
    #[serde(default)]
    views_count: u64,
    #[serde(default)]
    likes_count: u64,
}

#[derive(Debug, Deserialize)]
struct ProjectUser {
    username: String,
    full_name: String,
}

#[derive(Debug, Deserialize)]
struct ProjectAsset {
    #[serde(default)]
    is_image: bool,
    image_url: Url,
    #[serde(default)]
    original_url: Option<Url>,
    #[serde(default)]
    width: Option<u32>,
    #[serde(default)]
    height: Option<u32>,
}

impl Project {
    fn into_item(self) -> Option<WallpaperItem> {
        let mut variants = Vec::new();
        for asset in self.assets.into_iter().filter(|asset| asset.is_image) {
            if let Some(original) = asset.original_url.filter(is_https) {
                variants.push(WallpaperVariant {
                    url: original,
                    mime_type: None,
                    width: asset.width,
                    height: asset.height,
                    file_size: None,
                    checksum: None,
                });
            }
            if is_https(&asset.image_url)
                && !variants
                    .iter()
                    .any(|variant| variant.url == asset.image_url)
            {
                variants.push(WallpaperVariant {
                    url: asset.image_url,
                    mime_type: None,
                    width: asset.width,
                    height: asset.height,
                    file_size: None,
                    checksum: None,
                });
            }
        }
        if variants.is_empty() || !is_https(&self.permalink) {
            return None;
        }
        let author_url = Url::parse(&format!(
            "https://www.artstation.com/{}",
            self.user.username
        ))
        .ok();
        let mut metadata = BTreeMap::new();
        metadata.insert("artstation.project_id".into(), serde_json::json!(self.id));
        metadata.insert(
            "artstation.views".into(),
            serde_json::json!(self.views_count),
        );
        metadata.insert(
            "artstation.likes".into(),
            serde_json::json!(self.likes_count),
        );
        Some(WallpaperItem {
            id: self.hash_id,
            title: Some(self.title),
            description: self.description,
            author: Some(Author {
                name: self.user.full_name.clone(),
                url: author_url,
            }),
            source_page_url: self.permalink,
            license: None,
            attribution: Some(format!("Artwork by {} on ArtStation", self.user.full_name)),
            published_at: self.published_at,
            tags: Vec::new(),
            content_rating: if self.hide_as_adult {
                ContentRating::Adult
            } else {
                ContentRating::Safe
            },
            location: None,
            variants,
            metadata,
        })
    }
}

fn artstation_projects_url(
    config: &BTreeMap<String, serde_json::Value>,
) -> Result<Url, PluginError> {
    let raw = config
        .get("artist")
        .and_then(serde_json::Value::as_str)
        .map(str::trim)
        .filter(|value| !value.is_empty())
        .ok_or_else(|| PluginError::InvalidConfig("artist is required".into()))?;
    let username = artist_username(raw).ok_or_else(|| {
        PluginError::InvalidConfig("artist must be a username or ArtStation portfolio URL".into())
    })?;
    if !username
        .bytes()
        .all(|byte| byte.is_ascii_alphanumeric() || matches!(byte, b'_' | b'-'))
    {
        return Err(PluginError::InvalidConfig(
            "artist username contains unsupported characters".into(),
        ));
    }
    Url::parse(&format!("https://{username}.artstation.com/projects.json"))
        .map_err(|error| PluginError::InvalidConfig(error.to_string()))
}

fn artist_username(raw: &str) -> Option<String> {
    if !raw.starts_with("https://") {
        return Some(raw.into());
    }
    let url = Url::parse(raw).ok()?;
    let host = url.host_str()?;
    if host == "www.artstation.com" || host == "artstation.com" {
        return url
            .path_segments()?
            .find(|segment| !segment.is_empty())
            .map(Into::into);
    }
    host.strip_suffix(".artstation.com").map(Into::into)
}

fn is_https(url: &Url) -> bool {
    url.scheme() == "https" && url.host_str().is_some()
}

#[cfg(test)]
mod tests {
    use super::*;

    fn request() -> SourceRequest {
        SourceRequest {
            context: Default::default(),
            config: BTreeMap::from([("artist".into(), serde_json::json!("sample_artist"))]),
            query: None,
            cursor: None,
            limit: 20,
        }
    }

    #[test]
    fn username_becomes_scoped_json_request() {
        let built = ArtStationPlugin.build_list_request(&request()).unwrap();
        assert_eq!(
            built.url.as_str(),
            "https://sample_artist.artstation.com/projects.json"
        );
    }

    #[test]
    fn parses_public_portfolio_json_and_handles_error() {
        let page = ArtStationPlugin
            .parse_list_response(
                &request(),
                HostHttpResponse {
                    status: 200,
                    content_type: Some("application/json".into()),
                    body: include_bytes!("../tests/fixtures/projects.json").to_vec(),
                },
            )
            .unwrap();
        assert_eq!(page.items.len(), 1);
        assert_eq!(page.items[0].id, "ABC123");
        assert_eq!(
            page.items[0].attribution.as_deref(),
            Some("Artwork by Ada Artist on ArtStation")
        );
        assert!(matches!(
            ArtStationPlugin.parse_list_response(
                &request(),
                HostHttpResponse {
                    status: 503,
                    content_type: None,
                    body: Vec::new(),
                }
            ),
            Err(PluginError::HttpStatus(503))
        ));
    }
}
