use std::collections::BTreeMap;
use wallpaper_plugin_sdk::{
    ConfigSchema, ConfigUiSchema, ImageLayer, ImageProcessingOption, ImageProcessingRequest,
    ImageProcessorDescription, ImageRenderPlan, Plugin, PluginError, PluginManifest,
    SourceCapabilities,
};

pub struct ImageFitPlugin;

fn text(en: &str, zh: &str) -> BTreeMap<String, String> {
    BTreeMap::from([("en".into(), en.into()), ("zh".into(), zh.into())])
}

impl Plugin for ImageFitPlugin {
    fn manifest(&self) -> PluginManifest {
        PluginManifest::new(
            "org.wallpaper.processor.image-fit",
            "Still Image Fit",
            env!("CARGO_PKG_VERSION"),
            "Still",
            "Offline image composition for any screen shape",
            Vec::<String>::new(),
        )
    }
    fn config_schema(&self) -> ConfigSchema {
        ConfigSchema::default()
    }
    fn config_ui_schema(&self) -> ConfigUiSchema {
        ConfigUiSchema::default()
    }
    fn capabilities(&self) -> SourceCapabilities {
        SourceCapabilities::default()
    }
    fn validate_config(
        &self,
        _config: &BTreeMap<String, serde_json::Value>,
    ) -> Result<(), PluginError> {
        Ok(())
    }
    fn image_processor(&self) -> Option<ImageProcessorDescription> {
        Some(ImageProcessorDescription {
            options: vec![
                ImageProcessingOption {
                    id: "fill".into(),
                    label: text("Fill screen", "填满屏幕"),
                    description: text(
                        "Enlarge proportionally and crop the edges",
                        "等比放大，裁去超出屏幕的部分",
                    ),
                },
                ImageProcessingOption {
                    id: "fit".into(),
                    label: text("Show whole image", "完整显示"),
                    description: text(
                        "Keep every edge; leave space where needed",
                        "保留完整画面，空余区域留黑",
                    ),
                },
                ImageProcessingOption {
                    id: "stretch".into(),
                    label: text("Stretch", "拉伸"),
                    description: text(
                        "Fill the screen by changing the proportions",
                        "拉伸至屏幕大小，画面比例会改变",
                    ),
                },
                ImageProcessingOption {
                    id: "original".into(),
                    label: text("Original size", "原尺寸"),
                    description: text(
                        "Keep the original pixels, centered on screen",
                        "不缩放，居中显示，超出屏幕的部分裁去",
                    ),
                },
                ImageProcessingOption {
                    id: "blur".into(),
                    label: text("Blurred background", "虚化背景"),
                    description: text(
                        "Show the full image over a blurred backdrop",
                        "完整图片置于同图虚化背景之上",
                    ),
                },
            ],
        })
    }
    fn plan_image(&self, request: &ImageProcessingRequest) -> Result<ImageRenderPlan, PluginError> {
        let r = request;
        if [
            r.input_width,
            r.input_height,
            r.output_width,
            r.output_height,
        ]
        .contains(&0)
        {
            return Err(PluginError::InvalidConfig(
                "image and screen dimensions must be positive".into(),
            ));
        }
        let iw = r.input_width;
        let ih = r.input_height;
        let ow = r.output_width;
        let oh = r.output_height;
        let centered =
            |width: u32, height: u32, sx: u32, sy: u32, sw: u32, sh: u32, blur_sigma: f32| {
                ImageLayer {
                    source_x: sx,
                    source_y: sy,
                    source_width: sw,
                    source_height: sh,
                    width,
                    height,
                    x: ((i64::from(ow) - i64::from(width)) / 2) as i32,
                    y: ((i64::from(oh) - i64::from(height)) / 2) as i32,
                    blur_sigma,
                }
            };
        let fill = |blur| {
            let (cw, ch) = if u64::from(iw) * u64::from(oh) > u64::from(ih) * u64::from(ow) {
                (
                    ((u64::from(ih) * u64::from(ow)) / u64::from(oh)).max(1) as u32,
                    ih,
                )
            } else {
                (
                    iw,
                    ((u64::from(iw) * u64::from(oh)) / u64::from(ow)).max(1) as u32,
                )
            };
            centered(ow, oh, (iw - cw) / 2, (ih - ch) / 2, cw, ch, blur)
        };
        let fit = || {
            let scale = (f64::from(ow) / f64::from(iw)).min(f64::from(oh) / f64::from(ih));
            centered(
                (f64::from(iw) * scale).round().max(1.0) as u32,
                (f64::from(ih) * scale).round().max(1.0) as u32,
                0,
                0,
                iw,
                ih,
                0.0,
            )
        };
        let layers = match r.option.as_str() {
            "fill" => vec![fill(0.0)],
            "fit" => vec![fit()],
            "stretch" => vec![centered(ow, oh, 0, 0, iw, ih, 0.0)],
            "original" => {
                let w = iw.min(ow);
                let h = ih.min(oh);
                vec![centered(w, h, (iw - w) / 2, (ih - h) / 2, w, h, 0.0)]
            }
            "blur" => vec![fill(24.0), fit()],
            _ => {
                return Err(PluginError::InvalidConfig(
                    "unknown image fit option".into(),
                ));
            }
        };
        Ok(ImageRenderPlan {
            background: [0, 0, 0, 255],
            layers,
        })
    }
}

#[cfg(target_arch = "wasm32")]
wallpaper_plugin_sdk::export_source_plugin!(ImageFitPlugin);

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn portrait_modes_preserve_geometry_and_background_layers() {
        let mut r: ImageProcessingRequest =
            serde_json::from_str(include_str!("../tests/fixtures/portrait.json")).unwrap();
        let plan = ImageFitPlugin.plan_image(&r).unwrap();
        assert_eq!(plan.layers.len(), 2);
        assert_eq!((plan.layers[0].width, plan.layers[0].height), (1920, 1080));
        assert!(plan.layers[0].blur_sigma > 0.0);
        assert_eq!((plan.layers[1].width, plan.layers[1].height), (720, 1080));
        r.option = "original".into();
        let layer = ImageFitPlugin.plan_image(&r).unwrap().layers.remove(0);
        assert_eq!(
            (layer.width, layer.height, layer.x, layer.y),
            (600, 900, 660, 90)
        );
        r.option = "stretch".into();
        let layer = ImageFitPlugin.plan_image(&r).unwrap().layers.remove(0);
        assert_eq!(
            (
                layer.width,
                layer.height,
                layer.source_width,
                layer.source_height
            ),
            (1920, 1080, 600, 900)
        );
        r.option = "unknown".into();
        assert!(ImageFitPlugin.plan_image(&r).is_err());
        r.output_height = 0;
        assert!(ImageFitPlugin.plan_image(&r).is_err());
    }
}
