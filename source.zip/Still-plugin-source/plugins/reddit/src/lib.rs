use std::collections::BTreeMap;

use chrono::{DateTime, Utc};
use serde::Deserialize;
use url::Url;
use wallpaper_plugin_sdk::{
    Author, AuthorizationDescriptor, CardConfigItem, CardFieldWidth, ConfigField, ConfigFieldKind,
    ConfigSchema, ConfigUiSchema, ContentRating, CredentialInjection, CredentialRefresh,
    CredentialTarget, HostHttpRequest, HostHttpResponse, HttpMethod, NetworkPolicy, NetworkScope,
    PluginError, PluginManifest, SelectOption, SourceCapabilities, SourcePlugin, SourceRequest,
    WallpaperItem, WallpaperPage, WallpaperVariant, ensure_success,
};

#[derive(Debug, Default)]
pub struct RedditPlugin;

#[cfg(target_arch = "wasm32")]
wallpaper_plugin_sdk::export_source_plugin!(RedditPlugin);

impl SourcePlugin for RedditPlugin {
    fn manifest(&self) -> PluginManifest {
        let mut manifest = PluginManifest::new(
            "org.wallpaper.source.reddit",
            "Reddit",
            env!("CARGO_PKG_VERSION"),
            "Wallpaper contributors",
            "OAuth-only Reddit image listing with NSFW and deletion filtering",
            [
                "oauth.reddit.com",
                "www.reddit.com",
                "i.redd.it",
                "preview.redd.it",
                "i.imgur.com",
            ],
        );
        manifest.documentation_url = Url::parse("https://www.reddit.com/dev/api/").ok();
        manifest.network = NetworkPolicy {
            requests_per_minute: 50,
            max_concurrent_requests: 1,
            timeout_seconds: 20,
            max_retries: 1,
        };
        manifest
    }

    fn config_schema(&self) -> ConfigSchema {
        ConfigSchema {
            version: 1,
            fields: vec![
                ConfigField {
                    key: "source_type".into(),
                    label: "Source type".into(),
                    description: None,
                    required: true,
                    sensitive: false,
                    kind: ConfigFieldKind::Select {
                        options: vec![
                            SelectOption {
                                value: "subreddit".into(),
                                label: "Subreddit".into(),
                            },
                            SelectOption {
                                value: "user".into(),
                                label: "User submissions".into(),
                            },
                        ],
                    },
                },
                ConfigField {
                    key: "name".into(),
                    label: "Subreddit or username".into(),
                    description: None,
                    required: true,
                    sensitive: false,
                    kind: ConfigFieldKind::Text {
                        default: Some("EarthPorn".into()),
                    },
                },
                ConfigField {
                    key: "sort".into(),
                    label: "Sort".into(),
                    description: None,
                    required: true,
                    sensitive: false,
                    kind: ConfigFieldKind::Select {
                        options: ["hot", "new", "top"]
                            .into_iter()
                            .map(|value| SelectOption {
                                value: value.into(),
                                label: value.into(),
                            })
                            .collect(),
                    },
                },
                ConfigField {
                    key: "period".into(),
                    label: "Top period".into(),
                    description: None,
                    required: false,
                    sensitive: false,
                    kind: ConfigFieldKind::Select {
                        options: ["day", "week", "month", "year", "all"]
                            .into_iter()
                            .map(|value| SelectOption {
                                value: value.into(),
                                label: value.into(),
                            })
                            .collect(),
                    },
                },
                ConfigField {
                    key: "allow_nsfw".into(),
                    label: "Allow NSFW".into(),
                    description: None,
                    required: false,
                    sensitive: false,
                    kind: ConfigFieldKind::Toggle { default: false },
                },
                ConfigField {
                    key: "oauth_token".into(),
                    label: "OAuth access token".into(),
                    description: Some("A host-managed secret from a registered Reddit app".into()),
                    required: true,
                    sensitive: true,
                    kind: ConfigFieldKind::SecretReference,
                },
                ConfigField {
                    key: "client_id".into(),
                    label: "OAuth client ID".into(),
                    description: Some("Needed only for silent token renewal".into()),
                    required: false,
                    sensitive: false,
                    kind: ConfigFieldKind::Text { default: None },
                },
                ConfigField {
                    key: "client_secret".into(),
                    label: "OAuth client secret".into(),
                    description: Some("Stored in this source instance only".into()),
                    required: false,
                    sensitive: true,
                    kind: ConfigFieldKind::SecretReference,
                },
                ConfigField {
                    key: "oauth_refresh_token".into(),
                    label: "OAuth refresh token".into(),
                    description: Some("Allows silent renewal without prompting again".into()),
                    required: false,
                    sensitive: true,
                    kind: ConfigFieldKind::SecretReference,
                },
            ],
        }
    }

    fn config_ui_schema(&self) -> ConfigUiSchema {
        ConfigUiSchema {
            card: vec![
                CardConfigItem::new("source_type", CardFieldWidth::Half),
                CardConfigItem::new("name", CardFieldWidth::Half),
                CardConfigItem::new("sort", CardFieldWidth::Half),
                CardConfigItem::new("period", CardFieldWidth::Half),
                CardConfigItem::new("allow_nsfw", CardFieldWidth::Full),
                CardConfigItem::new("oauth_token", CardFieldWidth::Full),
                CardConfigItem::new("client_id", CardFieldWidth::Full),
                CardConfigItem::new("client_secret", CardFieldWidth::Half),
                CardConfigItem::new("oauth_refresh_token", CardFieldWidth::Half),
            ],
        }
    }

    fn capabilities(&self) -> SourceCapabilities {
        SourceCapabilities {
            list: true,
            ..Default::default()
        }
    }

    fn authorization(&self) -> Option<AuthorizationDescriptor> {
        Some(AuthorizationDescriptor {
            access_credential_key: "oauth_token".into(),
            refresh_before_seconds: 300,
        })
    }

    fn validate_config(
        &self,
        config: &BTreeMap<String, serde_json::Value>,
    ) -> Result<(), PluginError> {
        if !matches!(
            value(config, "source_type", "subreddit"),
            "subreddit" | "user"
        ) || !matches!(value(config, "sort", "hot"), "hot" | "new" | "top")
            || !matches!(
                value(config, "period", "week"),
                "day" | "week" | "month" | "year" | "all"
            )
        {
            return Err(PluginError::InvalidConfig(
                "unsupported Reddit source, sorting or time range".into(),
            ));
        }
        let name = config
            .get("name")
            .and_then(serde_json::Value::as_str)
            .unwrap_or("");
        if name.is_empty()
            || !name
                .bytes()
                .all(|byte| byte.is_ascii_alphanumeric() || matches!(byte, b'_' | b'-'))
        {
            return Err(PluginError::InvalidConfig(
                "name may contain only letters, digits, underscore and hyphen".into(),
            ));
        }
        if value(config, "oauth_token", "").trim().is_empty() {
            return Err(PluginError::InvalidConfig(
                "oauth_token secret reference is required".into(),
            ));
        }
        Ok(())
    }

    fn build_list_request(&self, request: &SourceRequest) -> Result<HostHttpRequest, PluginError> {
        self.validate_config(&request.config)?;
        let name = value(&request.config, "name", "EarthPorn");
        let sort = value(&request.config, "sort", "hot");
        let path = if value(&request.config, "source_type", "subreddit") == "user" {
            format!("/user/{name}/submitted")
        } else {
            format!("/r/{name}/{sort}")
        };
        let mut url = Url::parse("https://oauth.reddit.com")
            .unwrap()
            .join(&path)
            .unwrap();
        url.query_pairs_mut()
            .append_pair("raw_json", "1")
            .append_pair("limit", &request.limit.clamp(1, 100).to_string());
        if value(&request.config, "source_type", "subreddit") == "user" {
            url.query_pairs_mut().append_pair("sort", sort);
        }
        if sort == "top" {
            url.query_pairs_mut()
                .append_pair("t", value(&request.config, "period", "week"));
        }
        if let Some(cursor) = &request.cursor {
            url.query_pairs_mut().append_pair("after", cursor);
        }
        Ok(HostHttpRequest {
            method: HttpMethod::Get,
            url,
            headers: BTreeMap::from([
                ("Accept".into(), "application/json".into()),
                (
                    "User-Agent".into(),
                    format!(
                        "desktop:org.wallpaper.source.reddit:{}",
                        env!("CARGO_PKG_VERSION")
                    ),
                ),
            ]),
            form_fields: BTreeMap::new(),
            max_response_bytes: 4 * 1024 * 1024,
            network_scope: NetworkScope::DeclaredHost,
            credential_injections: vec![CredentialInjection {
                config_key: "oauth_token".into(),
                target: CredentialTarget::Header {
                    name: "Authorization".into(),
                    prefix: "Bearer ".into(),
                },
                required: true,
            }],
        })
    }

    fn parse_list_response(
        &self,
        request: &SourceRequest,
        response: HostHttpResponse,
    ) -> Result<WallpaperPage, PluginError> {
        ensure_success(&response)?;
        let listing: Listing = serde_json::from_slice(&response.body)
            .map_err(|error| PluginError::InvalidResponse(error.to_string()))?;
        let allow_nsfw = request
            .config
            .get("allow_nsfw")
            .and_then(serde_json::Value::as_bool)
            .unwrap_or(false);
        let items = listing
            .data
            .children
            .into_iter()
            .filter_map(|child| child.data.into_item(allow_nsfw))
            .take(usize::from(request.limit.max(1)))
            .collect();
        Ok(WallpaperPage {
            items,
            next_cursor: listing.data.after,
        })
    }

    fn build_authorization_refresh_request(
        &self,
        config: &BTreeMap<String, serde_json::Value>,
    ) -> Result<Option<HostHttpRequest>, PluginError> {
        if ["client_id", "client_secret", "oauth_refresh_token"]
            .into_iter()
            .any(|key| value(config, key, "").trim().is_empty())
        {
            return Ok(None);
        }
        Ok(Some(HostHttpRequest {
            method: HttpMethod::Post,
            url: Url::parse("https://www.reddit.com/api/v1/access_token").unwrap(),
            headers: BTreeMap::from([("Accept".into(), "application/json".into())]),
            form_fields: BTreeMap::from([("grant_type".into(), "refresh_token".into())]),
            max_response_bytes: 512 * 1024,
            network_scope: NetworkScope::DeclaredHost,
            credential_injections: vec![
                CredentialInjection {
                    config_key: "client_secret".into(),
                    target: CredentialTarget::BasicPassword {
                        username_config_key: "client_id".into(),
                    },
                    required: true,
                },
                CredentialInjection {
                    config_key: "oauth_refresh_token".into(),
                    target: CredentialTarget::Form {
                        name: "refresh_token".into(),
                    },
                    required: true,
                },
            ],
        }))
    }

    fn parse_authorization_refresh_response(
        &self,
        response: HostHttpResponse,
    ) -> Result<CredentialRefresh, PluginError> {
        ensure_success(&response)?;
        let response: OAuthRefreshResponse = serde_json::from_slice(&response.body)
            .map_err(|error| PluginError::InvalidResponse(error.to_string()))?;
        Ok(CredentialRefresh {
            access_token: response.access_token,
            expires_in_seconds: response.expires_in,
        })
    }
}

#[derive(Debug, Deserialize)]
struct OAuthRefreshResponse {
    access_token: String,
    expires_in: u64,
}

#[derive(Debug, Deserialize)]
struct Listing {
    data: ListingData,
}

#[derive(Debug, Deserialize)]
struct ListingData {
    #[serde(default)]
    after: Option<String>,
    children: Vec<ListingChild>,
}

#[derive(Debug, Deserialize)]
struct ListingChild {
    data: Post,
}

#[derive(Debug, Deserialize)]
struct Post {
    name: String,
    title: String,
    author: String,
    permalink: String,
    #[serde(default)]
    url_overridden_by_dest: Option<String>,
    #[serde(default)]
    over_18: bool,
    #[serde(default)]
    created_utc: Option<f64>,
    #[serde(default)]
    removed_by_category: Option<String>,
    #[serde(default)]
    preview: Option<Preview>,
}

#[derive(Debug, Deserialize)]
struct Preview {
    images: Vec<PreviewImage>,
}

#[derive(Debug, Deserialize)]
struct PreviewImage {
    source: PreviewSource,
}

#[derive(Debug, Deserialize)]
struct PreviewSource {
    url: String,
    #[serde(default)]
    width: Option<u32>,
    #[serde(default)]
    height: Option<u32>,
}

impl Post {
    fn into_item(self, allow_nsfw: bool) -> Option<WallpaperItem> {
        if self.removed_by_category.is_some() || (self.over_18 && !allow_nsfw) {
            return None;
        }
        let direct = self
            .url_overridden_by_dest
            .as_deref()
            .filter(|value| is_image_url(value) && is_reddit_image_host(value))
            .and_then(|value| Url::parse(value).ok());
        let preview = self
            .preview
            .as_ref()
            .and_then(|value| value.images.first())
            .map(|image| decode_entities(&image.source.url))
            .filter(|value| is_reddit_image_host(value))
            .and_then(|value| Url::parse(&value).ok());
        let uses_preview = direct.is_none();
        let image_url = direct.or(preview)?;
        let preview_size = uses_preview
            .then_some(
                self.preview
                    .as_ref()
                    .and_then(|value| value.images.first())
                    .map(|image| (&image.source.width, &image.source.height)),
            )
            .flatten();
        let source_page_url = Url::parse("https://www.reddit.com")
            .ok()?
            .join(&self.permalink)
            .ok()?;
        Some(WallpaperItem {
            id: self.name,
            title: Some(self.title),
            description: None,
            author: Some(Author {
                name: self.author.clone(),
                url: Url::parse(&format!("https://www.reddit.com/user/{}", self.author)).ok(),
            }),
            source_page_url,
            license: None,
            attribution: Some(format!(
                "Posted by u/{} on Reddit; rights remain with the owner",
                self.author
            )),
            published_at: self
                .created_utc
                .and_then(|seconds| DateTime::<Utc>::from_timestamp(seconds as i64, 0)),
            tags: Vec::new(),
            content_rating: if self.over_18 {
                ContentRating::Adult
            } else {
                ContentRating::Unknown
            },
            location: None,
            variants: vec![WallpaperVariant {
                url: image_url,
                mime_type: None,
                width: preview_size.and_then(|(width, _)| *width),
                height: preview_size.and_then(|(_, height)| *height),
                file_size: None,
                checksum: None,
            }],
            metadata: BTreeMap::new(),
        })
    }
}

fn is_image_url(value: &str) -> bool {
    let lowercase = value.to_ascii_lowercase();
    [".jpg", ".jpeg", ".png", ".webp"].iter().any(|extension| {
        lowercase
            .split('?')
            .next()
            .is_some_and(|path| path.ends_with(extension))
    })
}

fn is_reddit_image_host(value: &str) -> bool {
    Url::parse(value).ok().is_some_and(|url| {
        url.scheme() == "https"
            && matches!(
                url.host_str(),
                Some("i.redd.it" | "preview.redd.it" | "i.imgur.com")
            )
    })
}

fn decode_entities(value: &str) -> String {
    value.replace("&amp;", "&")
}

fn value<'a>(
    config: &'a BTreeMap<String, serde_json::Value>,
    key: &str,
    default: &'a str,
) -> &'a str {
    config
        .get(key)
        .and_then(serde_json::Value::as_str)
        .unwrap_or(default)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn imgur_original_is_used_before_a_lower_quality_reddit_preview() {
        let post: Post = serde_json::from_value(serde_json::json!({
            "name": "t3_imgur", "title": "Original", "author": "ada",
            "permalink": "/r/EarthPorn/comments/imgur/original/",
            "url_overridden_by_dest": "https://i.imgur.com/ABC123.jpg",
            "preview": {"images": [{"source": {"url": "https://preview.redd.it/preview.jpg?width=640&amp;auto=webp", "width": 640, "height": 360}}]}
        })).unwrap();
        let item = post.into_item(false).unwrap();
        assert_eq!(
            item.variants[0].url.as_str(),
            "https://i.imgur.com/ABC123.jpg"
        );
        assert_eq!(
            item.variants[0].width, None,
            "preview dimensions do not describe the original image"
        );
        assert!(
            RedditPlugin
                .manifest()
                .allowed_hosts
                .iter()
                .any(|host| host == "i.imgur.com")
        );
    }

    #[test]
    fn user_listing_sends_sort_and_time_range() {
        let req = SourceRequest {
            context: Default::default(),
            config: BTreeMap::from([
                ("source_type".into(), serde_json::json!("user")),
                ("name".into(), serde_json::json!("ada")),
                ("sort".into(), serde_json::json!("top")),
                ("period".into(), serde_json::json!("year")),
                ("oauth_token".into(), serde_json::json!("secret:reddit")),
            ]),
            query: None,
            cursor: Some("t3_next".into()),
            limit: 20,
        };
        let built = RedditPlugin.build_list_request(&req).unwrap();
        assert_eq!(built.url.path(), "/user/ada/submitted");
        let pairs: BTreeMap<_, _> = built.url.query_pairs().into_owned().collect();
        assert_eq!(pairs["sort"], "top");
        assert_eq!(pairs["t"], "year");
        assert_eq!(pairs["after"], "t3_next");
    }

    #[test]
    fn filters_nsfw_and_non_image_posts_and_keeps_cursor() {
        let body = include_bytes!("../tests/fixtures/list.json");
        let request = SourceRequest {
            context: Default::default(),
            config: BTreeMap::from([("allow_nsfw".into(), serde_json::json!(false))]),
            query: None,
            cursor: None,
            limit: 20,
        };
        let page = RedditPlugin
            .parse_list_response(
                &request,
                HostHttpResponse {
                    status: 200,
                    content_type: Some("application/json".into()),
                    body: body.to_vec(),
                },
            )
            .unwrap();
        assert_eq!(page.items.len(), 1);
        assert_eq!(page.next_cursor.as_deref(), Some("t3_next"));
    }

    #[test]
    fn handles_empty_listing_and_http_error() {
        let request = SourceRequest {
            context: Default::default(),
            config: BTreeMap::new(),
            query: None,
            cursor: None,
            limit: 20,
        };
        let empty = RedditPlugin
            .parse_list_response(
                &request,
                HostHttpResponse {
                    status: 200,
                    content_type: Some("application/json".into()),
                    body: br#"{"data":{"after":null,"children":[]}}"#.to_vec(),
                },
            )
            .unwrap();
        assert!(empty.items.is_empty());
        assert!(matches!(
            RedditPlugin.parse_list_response(
                &request,
                HostHttpResponse {
                    status: 401,
                    content_type: None,
                    body: Vec::new(),
                }
            ),
            Err(PluginError::HttpStatus(401))
        ));
    }
}
