use serde::{Deserialize, Serialize};
use std::collections::BTreeMap;

/// Options are owned by the installed processor, including their localized
/// names. The shell never enumerates product-specific fit modes.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ImageProcessorDescription {
    pub options: Vec<ImageProcessingOption>,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ImageProcessingOption {
    pub id: String,
    pub label: BTreeMap<String, String>,
    pub description: BTreeMap<String, String>,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ImageProcessingRequest {
    pub option: String,
    pub input_width: u32,
    pub input_height: u32,
    pub output_width: u32,
    pub output_height: u32,
}

/// Bounded image composition primitives executed by the host. Plugins choose
/// geometry and effects; files and pixel buffers never enter the Wasm sandbox.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ImageRenderPlan {
    pub background: [u8; 4],
    pub layers: Vec<ImageLayer>,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ImageLayer {
    pub source_x: u32,
    pub source_y: u32,
    pub source_width: u32,
    pub source_height: u32,
    pub width: u32,
    pub height: u32,
    pub x: i32,
    pub y: i32,
    pub blur_sigma: f32,
}
