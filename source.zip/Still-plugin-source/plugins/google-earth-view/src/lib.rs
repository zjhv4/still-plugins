use std::collections::BTreeMap;

use serde::Deserialize;
use url::Url;
use wallpaper_plugin_sdk::paginate_items;
use wallpaper_plugin_sdk::{
    CardConfigItem, CardFieldWidth, ConfigField, ConfigFieldKind, ConfigSchema, ConfigUiSchema,
    ContentRating, HostHttpRequest, HostHttpResponse, HttpMethod, License, Location, NetworkPolicy,
    NetworkScope, PluginError, PluginManifest, SourceCapabilities, SourcePlugin, SourceRequest,
    WallpaperItem, WallpaperPage, WallpaperVariant, ensure_success,
};

#[derive(Debug, Default)]
pub struct GoogleEarthViewPlugin;

#[cfg(target_arch = "wasm32")]
wallpaper_plugin_sdk::export_source_plugin!(GoogleEarthViewPlugin);

impl SourcePlugin for GoogleEarthViewPlugin {
    fn manifest(&self) -> PluginManifest {
        let mut manifest = PluginManifest::new(
            "org.wallpaper.source.google-earth-view",
            "Google Earth View",
            env!("CARGO_PKG_VERSION"),
            "Wallpaper contributors",
            "Compatibility adapter for an authorized Earth View JSON catalog",
            Vec::<String>::new(),
        );
        manifest.documentation_url = Url::parse(
            "https://blog.google/products/earth/most-stunning-images-from-google-earth/",
        )
        .ok();
        manifest.network = NetworkPolicy {
            requests_per_minute: 2,
            max_concurrent_requests: 1,
            timeout_seconds: 20,
            max_retries: 1,
        };
        manifest
    }

    fn config_schema(&self) -> ConfigSchema {
        ConfigSchema {
            version: 1,
            fields: vec![
                ConfigField {
                    key: "catalog_url".into(),
                    label: "Authorized catalog URL".into(),
                    description: Some("Defaults to the community-maintained archived Earth View catalog; replace it with an authorized schema-v1 catalog if needed".into()),
                    required: true,
                    sensitive: false,
                    kind: ConfigFieldKind::Url {
                        default: Url::parse("https://raw.githubusercontent.com/limhenry/earthview/master/earthview.json").ok(),
                    },
                },
                ConfigField {
                    key: "region".into(),
                    label: "Region filter".into(),
                    description: Some("Optional case-insensitive region or country".into()),
                    required: false,
                    sensitive: false,
                    kind: ConfigFieldKind::Text { default: None },
                },
            ],
        }
    }

    fn config_ui_schema(&self) -> ConfigUiSchema {
        ConfigUiSchema {
            card: vec![
                CardConfigItem::new("region", CardFieldWidth::Half),
                CardConfigItem::new("catalog_url", CardFieldWidth::Full),
            ],
        }
    }

    fn capabilities(&self) -> SourceCapabilities {
        SourceCapabilities {
            list: true,
            random: true,
            ..Default::default()
        }
    }

    fn validate_config(
        &self,
        config: &BTreeMap<String, serde_json::Value>,
    ) -> Result<(), PluginError> {
        catalog_url(config).map(|_| ())
    }

    fn build_list_request(&self, request: &SourceRequest) -> Result<HostHttpRequest, PluginError> {
        let url = catalog_url(&request.config)?;
        Ok(HostHttpRequest {
            method: HttpMethod::Get,
            url,
            headers: BTreeMap::from([("Accept".into(), "application/json".into())]),
            form_fields: BTreeMap::new(),
            max_response_bytes: 8 * 1024 * 1024,
            network_scope: NetworkScope::ConfiguredUrl {
                config_key: "catalog_url".into(),
            },
            credential_injections: Vec::new(),
        })
    }

    fn parse_list_response(
        &self,
        request: &SourceRequest,
        response: HostHttpResponse,
    ) -> Result<WallpaperPage, PluginError> {
        ensure_success(&response)?;
        let payload: Catalog = serde_json::from_slice(&response.body)
            .map_err(|error| PluginError::InvalidResponse(error.to_string()))?;
        if payload.schema_version != 1 {
            return Err(PluginError::InvalidResponse(format!(
                "unsupported Earth View catalog schema {}",
                payload.schema_version
            )));
        }
        let filter = request
            .config
            .get("region")
            .and_then(serde_json::Value::as_str)
            .unwrap_or("")
            .to_lowercase();
        let items = payload
            .items
            .into_iter()
            .filter(|entry| {
                filter.is_empty()
                    || entry.country.to_lowercase().contains(&filter)
                    || entry.region.to_lowercase().contains(&filter)
            })
            .filter_map(EarthViewEntry::into_item)
            .collect();
        paginate_items(items, request)
    }

    fn build_random_request(
        &self,
        request: &SourceRequest,
    ) -> Result<HostHttpRequest, PluginError> {
        self.build_list_request(request)
    }

    fn parse_random_response(
        &self,
        request: &SourceRequest,
        response: HostHttpResponse,
    ) -> Result<WallpaperPage, PluginError> {
        let mut all_request = request.clone();
        all_request.limit = u16::MAX;
        all_request.cursor = None;
        let mut page = self.parse_list_response(&all_request, response)?;
        deterministic_shuffle(&mut page.items, request.context.random_seed);
        if page.items.len() > usize::from(request.limit.max(1)) {
            page.items.truncate(usize::from(request.limit.max(1)));
        }
        Ok(page)
    }
}

/// Fisher–Yates driven only by the host-provided seed. Keeping this tiny PRNG
/// local avoids pulling an operating-system random backend into a no-WASI
/// plugin while preserving reproducible random results.
fn deterministic_shuffle<T>(items: &mut [T], seed: u64) {
    let mut state = seed;
    for upper in (1..items.len()).rev() {
        state = state.wrapping_add(0x9e37_79b9_7f4a_7c15);
        let mut value = state;
        value = (value ^ (value >> 30)).wrapping_mul(0xbf58_476d_1ce4_e5b9);
        value = (value ^ (value >> 27)).wrapping_mul(0x94d0_49bb_1331_11eb);
        value ^= value >> 31;
        items.swap(upper, value as usize % (upper + 1));
    }
}

#[derive(Debug, Deserialize)]
struct Catalog {
    schema_version: u32,
    items: Vec<EarthViewEntry>,
}

#[derive(Debug, Deserialize)]
struct EarthViewEntry {
    id: String,
    title: String,
    image_url: Url,
    source_page_url: Url,
    country: String,
    region: String,
    #[serde(default)]
    latitude: Option<f64>,
    #[serde(default)]
    longitude: Option<f64>,
    attribution: String,
    #[serde(default)]
    width: Option<u32>,
    #[serde(default)]
    height: Option<u32>,
}

impl EarthViewEntry {
    fn into_item(self) -> Option<WallpaperItem> {
        if !is_https(&self.image_url) || !is_https(&self.source_page_url) {
            return None;
        }
        Some(WallpaperItem {
            id: self.id,
            title: Some(self.title),
            description: Some(format!("{}, {}", self.region, self.country)),
            author: None,
            source_page_url: self.source_page_url,
            license: Some(License {
                name: "Google Earth attribution and usage terms".into(),
                url: Url::parse("https://www.google.com/help/terms_maps/").ok(),
            }),
            attribution: Some(self.attribution),
            published_at: None,
            tags: vec![self.region.clone(), self.country.clone()],
            content_rating: ContentRating::Safe,
            location: Some(Location {
                country: Some(self.country),
                region: Some(self.region),
                latitude: self.latitude,
                longitude: self.longitude,
            }),
            variants: vec![WallpaperVariant {
                url: self.image_url,
                mime_type: None,
                width: self.width,
                height: self.height,
                file_size: None,
                checksum: None,
            }],
            metadata: BTreeMap::new(),
        })
    }
}

fn is_https(url: &Url) -> bool {
    url.scheme() == "https" && url.host_str().is_some()
}

fn catalog_url(config: &BTreeMap<String, serde_json::Value>) -> Result<Url, PluginError> {
    let raw = config
        .get("catalog_url")
        .and_then(serde_json::Value::as_str)
        .ok_or_else(|| PluginError::InvalidConfig("catalog_url is required".into()))?;
    let url = Url::parse(raw).map_err(|error| PluginError::InvalidConfig(error.to_string()))?;
    if url.scheme() != "https" || url.host_str().is_none() {
        return Err(PluginError::InvalidConfig(
            "catalog_url must be an absolute HTTPS URL".into(),
        ));
    }
    Ok(url)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_versioned_catalog_and_region_filter() {
        let request = SourceRequest {
            context: Default::default(),
            config: BTreeMap::from([
                (
                    "catalog_url".into(),
                    serde_json::json!("https://catalog.example/earth-view.json"),
                ),
                ("region".into(), serde_json::json!("greenland")),
            ]),
            query: None,
            cursor: None,
            limit: 20,
        };
        let body = include_bytes!("../tests/fixtures/catalog.json");
        let page = GoogleEarthViewPlugin
            .parse_list_response(
                &request,
                HostHttpResponse {
                    status: 200,
                    content_type: Some("application/json".into()),
                    body: body.to_vec(),
                },
            )
            .unwrap();
        assert_eq!(page.items.len(), 1);
        assert_eq!(page.items[0].id, "greenland-1");
    }

    #[test]
    fn handles_empty_catalog_and_http_error() {
        let request = SourceRequest {
            context: Default::default(),
            config: BTreeMap::from([(
                "catalog_url".into(),
                serde_json::json!("https://catalog.example/earth-view.json"),
            )]),
            query: None,
            cursor: None,
            limit: 20,
        };
        let empty = GoogleEarthViewPlugin
            .parse_list_response(
                &request,
                HostHttpResponse {
                    status: 200,
                    content_type: Some("application/json".into()),
                    body: br#"{"schema_version":1,"items":[]}"#.to_vec(),
                },
            )
            .unwrap();
        assert!(empty.items.is_empty());
        assert!(matches!(
            GoogleEarthViewPlugin.parse_list_response(
                &request,
                HostHttpResponse {
                    status: 404,
                    content_type: None,
                    body: Vec::new(),
                }
            ),
            Err(PluginError::HttpStatus(404))
        ));
    }
}
