use std::collections::BTreeMap;

use chrono::{DateTime, Utc};
use serde::Deserialize;
use url::Url;
use wallpaper_plugin_sdk::{
    Author, CardConfigItem, CardFieldWidth, ConfigField, ConfigFieldKind, ConfigSchema,
    ConfigUiSchema, ContentRating, CredentialInjection, CredentialTarget, HostHttpRequest,
    HostHttpResponse, HttpMethod, License, Location, NetworkPolicy, NetworkScope, PluginError,
    PluginManifest, SelectOption, SourceCapabilities, SourcePlugin, SourceRequest, WallpaperItem,
    WallpaperPage, WallpaperVariant, ensure_success, page_number,
};

#[derive(Debug, Default)]
pub struct UnsplashPlugin;

#[cfg(target_arch = "wasm32")]
wallpaper_plugin_sdk::export_source_plugin!(UnsplashPlugin);

impl SourcePlugin for UnsplashPlugin {
    fn manifest(&self) -> PluginManifest {
        let mut manifest = PluginManifest::new(
            "org.wallpaper.source.unsplash",
            "Unsplash",
            env!("CARGO_PKG_VERSION"),
            "Wallpaper contributors",
            "Official Unsplash API client for random, search, user, collection and topic photos",
            ["api.unsplash.com", "images.unsplash.com", "unsplash.com"],
        );
        manifest.documentation_url = Url::parse("https://unsplash.com/documentation").ok();
        manifest.network = NetworkPolicy {
            requests_per_minute: 40,
            max_concurrent_requests: 2,
            timeout_seconds: 20,
            max_retries: 1,
        };
        manifest
    }

    fn config_schema(&self) -> ConfigSchema {
        ConfigSchema {
            version: 1,
            fields: vec![
                ConfigField {
                    key: "mode".into(),
                    label: "Source mode".into(),
                    description: Some("Unsplash Source is retired; all modes use API v1".into()),
                    required: true,
                    sensitive: false,
                    kind: ConfigFieldKind::Select {
                        options: [
                            ("latest", "Latest"),
                            ("random", "Random"),
                            ("search", "Search"),
                            ("user", "User"),
                            ("collection", "Collection"),
                            ("topic", "Topic"),
                        ]
                        .into_iter()
                        .map(|(value, label)| SelectOption {
                            value: value.into(),
                            label: label.into(),
                        })
                        .collect(),
                    },
                },
                ConfigField {
                    key: "identifier".into(),
                    label: "Query or identifier".into(),
                    description: Some("Keyword, username, collection ID, or topic slug".into()),
                    required: false,
                    sensitive: false,
                    kind: ConfigFieldKind::Text {
                        default: Some("nature".into()),
                    },
                },
                ConfigField {
                    key: "content_filter".into(),
                    label: "Content filter".into(),
                    description: None,
                    required: true,
                    sensitive: false,
                    kind: ConfigFieldKind::Select {
                        options: vec![
                            SelectOption {
                                value: "high".into(),
                                label: "High".into(),
                            },
                            SelectOption {
                                value: "low".into(),
                                label: "Low".into(),
                            },
                        ],
                    },
                },
                ConfigField {
                    key: "access_key".into(),
                    label: "Unsplash access key".into(),
                    description: Some(
                        "Stored by the host and injected as a Client-ID header".into(),
                    ),
                    required: true,
                    sensitive: true,
                    kind: ConfigFieldKind::SecretReference,
                },
            ],
        }
    }

    fn config_ui_schema(&self) -> ConfigUiSchema {
        ConfigUiSchema {
            card: vec![
                CardConfigItem::new("mode", CardFieldWidth::Half),
                CardConfigItem::new("identifier", CardFieldWidth::Half),
                CardConfigItem::new("content_filter", CardFieldWidth::Half),
                CardConfigItem::new("access_key", CardFieldWidth::Full),
            ],
        }
    }

    fn capabilities(&self) -> SourceCapabilities {
        SourceCapabilities {
            list: true,
            search: true,
            random: true,
            ..Default::default()
        }
    }

    fn validate_config(
        &self,
        config: &BTreeMap<String, serde_json::Value>,
    ) -> Result<(), PluginError> {
        let mode = value(config, "mode", "latest");
        if !matches!(
            mode,
            "latest" | "random" | "search" | "user" | "collection" | "topic"
        ) {
            return Err(PluginError::InvalidConfig(
                "unsupported Unsplash mode".into(),
            ));
        }
        if matches!(mode, "search" | "user" | "collection" | "topic")
            && value(config, "identifier", "").trim().is_empty()
        {
            return Err(PluginError::InvalidConfig(
                "identifier is required for this mode".into(),
            ));
        }
        if value(config, "access_key", "").trim().is_empty() {
            return Err(PluginError::InvalidConfig(
                "access_key secret reference is required".into(),
            ));
        }
        Ok(())
    }

    fn build_list_request(&self, request: &SourceRequest) -> Result<HostHttpRequest, PluginError> {
        self.build_request(request, None)
    }

    fn parse_list_response(
        &self,
        request: &SourceRequest,
        response: HostHttpResponse,
    ) -> Result<WallpaperPage, PluginError> {
        parse_response(request, response)
    }

    fn build_search_request(
        &self,
        request: &SourceRequest,
    ) -> Result<HostHttpRequest, PluginError> {
        self.build_request(request, request.query.as_deref())
    }

    fn parse_search_response(
        &self,
        request: &SourceRequest,
        response: HostHttpResponse,
    ) -> Result<WallpaperPage, PluginError> {
        parse_response(request, response)
    }

    fn build_random_request(
        &self,
        request: &SourceRequest,
    ) -> Result<HostHttpRequest, PluginError> {
        let mut config = request.config.clone();
        config.insert("mode".into(), serde_json::json!("random"));
        self.build_request(
            &SourceRequest {
                config,
                ..request.clone()
            },
            request.query.as_deref(),
        )
    }

    fn parse_random_response(
        &self,
        request: &SourceRequest,
        response: HostHttpResponse,
    ) -> Result<WallpaperPage, PluginError> {
        parse_response(request, response)
    }

    fn build_download_event_request(
        &self,
        item: &WallpaperItem,
        config: &BTreeMap<String, serde_json::Value>,
    ) -> Result<Option<HostHttpRequest>, PluginError> {
        self.validate_config(config)?;
        let url = item
            .metadata
            .get("unsplash.download_location")
            .and_then(serde_json::Value::as_str)
            .ok_or_else(|| {
                PluginError::InvalidResponse("missing Unsplash download location".into())
            })?;
        let url =
            Url::parse(url).map_err(|error| PluginError::InvalidResponse(error.to_string()))?;
        Ok(Some(HostHttpRequest {
            method: HttpMethod::Get,
            url,
            headers: BTreeMap::from([
                ("Accept".into(), "application/json".into()),
                ("Accept-Version".into(), "v1".into()),
            ]),
            form_fields: BTreeMap::new(),
            max_response_bytes: 512 * 1024,
            network_scope: NetworkScope::DeclaredHost,
            credential_injections: vec![CredentialInjection {
                config_key: "access_key".into(),
                target: CredentialTarget::Header {
                    name: "Authorization".into(),
                    prefix: "Client-ID ".into(),
                },
                required: true,
            }],
        }))
    }
}

impl UnsplashPlugin {
    fn build_request(
        &self,
        request: &SourceRequest,
        query_override: Option<&str>,
    ) -> Result<HostHttpRequest, PluginError> {
        self.validate_config(&request.config)?;
        let mode = if query_override.is_some() {
            "search"
        } else {
            value(&request.config, "mode", "latest")
        };
        let identifier = query_override.unwrap_or_else(|| value(&request.config, "identifier", ""));
        let path = match mode {
            "random" => "/photos/random".to_owned(),
            "search" => "/search/photos".to_owned(),
            "user" => format!("/users/{identifier}/photos"),
            "collection" => format!("/collections/{identifier}/photos"),
            "topic" => format!("/topics/{identifier}/photos"),
            _ => "/photos".to_owned(),
        };
        let mut url = Url::parse("https://api.unsplash.com")
            .unwrap()
            .join(&path)
            .unwrap();
        let page = if mode == "random" {
            1
        } else {
            page_number(request.cursor.as_deref())?
        };
        {
            let mut pairs = url.query_pairs_mut();
            if mode == "random" {
                pairs.append_pair("count", &request.limit.clamp(1, 30).to_string());
                if !identifier.is_empty() {
                    pairs.append_pair("query", identifier);
                }
            } else {
                pairs
                    .append_pair("page", &page.to_string())
                    .append_pair("per_page", &request.limit.clamp(1, 30).to_string());
                if mode == "search" {
                    pairs.append_pair("query", identifier).append_pair(
                        "content_filter",
                        value(&request.config, "content_filter", "high"),
                    );
                }
            }
        }
        Ok(HostHttpRequest {
            method: HttpMethod::Get,
            url,
            headers: BTreeMap::from([
                ("Accept".into(), "application/json".into()),
                ("Accept-Version".into(), "v1".into()),
            ]),
            form_fields: BTreeMap::new(),
            max_response_bytes: 4 * 1024 * 1024,
            network_scope: NetworkScope::DeclaredHost,
            credential_injections: vec![CredentialInjection {
                config_key: "access_key".into(),
                target: CredentialTarget::Header {
                    name: "Authorization".into(),
                    prefix: "Client-ID ".into(),
                },
                required: true,
            }],
        })
    }
}

#[derive(Debug, Deserialize)]
struct SearchEnvelope {
    results: Vec<Photo>,
    #[serde(default)]
    total_pages: Option<u32>,
}

#[derive(Debug, Deserialize)]
struct Photo {
    id: String,
    #[serde(default)]
    description: Option<String>,
    #[serde(default)]
    alt_description: Option<String>,
    width: u32,
    height: u32,
    #[serde(default)]
    created_at: Option<DateTime<Utc>>,
    urls: PhotoUrls,
    links: PhotoLinks,
    user: PhotoUser,
    #[serde(default)]
    color: Option<String>,
    #[serde(default)]
    location: Option<PhotoLocation>,
    #[serde(default)]
    tags: Vec<PhotoTag>,
}

#[derive(Debug, Deserialize)]
struct PhotoUrls {
    raw: Url,
    full: Url,
    regular: Url,
}

#[derive(Debug, Deserialize)]
struct PhotoLinks {
    html: Url,
    download_location: Url,
}

#[derive(Debug, Deserialize)]
struct PhotoUser {
    name: String,
    links: UserLinks,
}

#[derive(Debug, Deserialize)]
struct UserLinks {
    html: Url,
}

#[derive(Debug, Deserialize)]
struct PhotoLocation {
    #[serde(default)]
    country: Option<String>,
    #[serde(default)]
    position: Option<Position>,
}

#[derive(Debug, Deserialize)]
struct Position {
    #[serde(default)]
    latitude: Option<f64>,
    #[serde(default)]
    longitude: Option<f64>,
}

#[derive(Debug, Deserialize)]
struct PhotoTag {
    title: String,
}

fn parse_response(
    request: &SourceRequest,
    response: HostHttpResponse,
) -> Result<WallpaperPage, PluginError> {
    ensure_success(&response)?;
    let value: serde_json::Value = serde_json::from_slice(&response.body)
        .map_err(|error| PluginError::InvalidResponse(error.to_string()))?;
    let (photos, total_pages) = if value.get("results").is_some() {
        let envelope: SearchEnvelope = serde_json::from_value(value)
            .map_err(|error| PluginError::InvalidResponse(error.to_string()))?;
        (envelope.results, envelope.total_pages)
    } else if value.is_array() {
        (
            serde_json::from_value(value)
                .map_err(|error| PluginError::InvalidResponse(error.to_string()))?,
            None,
        )
    } else {
        (
            vec![
                serde_json::from_value(value)
                    .map_err(|error| PluginError::InvalidResponse(error.to_string()))?,
            ],
            None,
        )
    };
    let random = request
        .config
        .get("mode")
        .and_then(serde_json::Value::as_str)
        == Some("random");
    let current_page = if random {
        1
    } else {
        page_number(request.cursor.as_deref())?
    };
    let next_cursor = if random {
        (!photos.is_empty()).then(|| format!("random:{}", request.context.random_seed))
    } else if total_pages.is_some_and(|total| current_page < total)
        || total_pages.is_none() && photos.len() >= usize::from(request.limit.clamp(1, 30))
    {
        Some((current_page + 1).to_string())
    } else {
        None
    };
    Ok(WallpaperPage {
        items: photos.into_iter().map(Photo::into_item).collect(),
        next_cursor,
    })
}

impl Photo {
    fn into_item(self) -> WallpaperItem {
        let mut author_url = self.user.links.html;
        author_url
            .query_pairs_mut()
            .append_pair("utm_source", "wallpaper")
            .append_pair("utm_medium", "referral");
        let position = self
            .location
            .as_ref()
            .and_then(|location| location.position.as_ref());
        let location = self.location.as_ref().map(|source| Location {
            country: source.country.clone(),
            region: None,
            latitude: position.and_then(|value| value.latitude),
            longitude: position.and_then(|value| value.longitude),
        });
        let mut metadata = BTreeMap::new();
        metadata.insert(
            "unsplash.download_location".into(),
            serde_json::json!(self.links.download_location),
        );
        if let Some(color) = self.color {
            metadata.insert("unsplash.color".into(), serde_json::json!(color));
        }
        WallpaperItem {
            id: self.id,
            title: self.description.clone().or(self.alt_description.clone()),
            description: self.description.or(self.alt_description),
            author: Some(Author {
                name: self.user.name.clone(),
                url: Some(author_url),
            }),
            source_page_url: self.links.html,
            license: Some(License {
                name: "Unsplash License".into(),
                url: Url::parse("https://unsplash.com/license").ok(),
            }),
            attribution: Some(format!("Photo by {} on Unsplash", self.user.name)),
            published_at: self.created_at,
            tags: self.tags.into_iter().map(|tag| tag.title).collect(),
            content_rating: ContentRating::Safe,
            location,
            variants: vec![
                unsplash_variant(self.urls.raw, self.width, self.height),
                unsplash_variant(self.urls.full, self.width, self.height),
                WallpaperVariant {
                    url: self.urls.regular,
                    mime_type: Some("image/jpeg".into()),
                    width: Some(1080),
                    height: None,
                    file_size: None,
                    checksum: None,
                },
            ],
            metadata,
        }
    }
}

fn unsplash_variant(url: Url, width: u32, height: u32) -> WallpaperVariant {
    WallpaperVariant {
        url,
        mime_type: Some("image/jpeg".into()),
        width: Some(width),
        height: Some(height),
        file_size: None,
        checksum: None,
    }
}

fn value<'a>(
    config: &'a BTreeMap<String, serde_json::Value>,
    key: &str,
    default: &'a str,
) -> &'a str {
    config
        .get(key)
        .and_then(serde_json::Value::as_str)
        .unwrap_or(default)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn request() -> SourceRequest {
        SourceRequest {
            context: Default::default(),
            config: BTreeMap::from([
                ("mode".into(), serde_json::json!("search")),
                ("identifier".into(), serde_json::json!("nature")),
                ("content_filter".into(), serde_json::json!("high")),
            ]),
            query: None,
            cursor: None,
            limit: 20,
        }
    }

    #[test]
    fn parses_photo_and_preserves_download_tracking_url() {
        let body = include_bytes!("../tests/fixtures/search.json");
        let page = UnsplashPlugin
            .parse_list_response(
                &request(),
                HostHttpResponse {
                    status: 200,
                    content_type: Some("application/json".into()),
                    body: body.to_vec(),
                },
            )
            .unwrap();
        assert_eq!(page.next_cursor.as_deref(), Some("2"));
        assert_eq!(page.items[0].author.as_ref().unwrap().name, "Ada");
        assert!(
            page.items[0]
                .metadata
                .contains_key("unsplash.download_location")
        );
    }

    #[test]
    fn handles_empty_search_and_http_error() {
        let empty = UnsplashPlugin
            .parse_list_response(
                &request(),
                HostHttpResponse {
                    status: 200,
                    content_type: Some("application/json".into()),
                    body: br#"{"total_pages":0,"results":[]}"#.to_vec(),
                },
            )
            .unwrap();
        assert!(empty.items.is_empty());
        assert!(matches!(
            UnsplashPlugin.parse_list_response(
                &request(),
                HostHttpResponse {
                    status: 403,
                    content_type: None,
                    body: Vec::new(),
                }
            ),
            Err(PluginError::HttpStatus(403))
        ));
    }
}
