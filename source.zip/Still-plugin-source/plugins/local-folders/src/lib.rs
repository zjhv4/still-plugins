use std::collections::BTreeMap;

use wallpaper_plugin_sdk::{
    ConfigSchema, ConfigUiSchema, HostHttpRequest, HostHttpResponse, PluginError, PluginManifest,
    SourceCapabilities, SourcePlugin, SourceRequest, WallpaperPage,
};

#[derive(Debug, Default)]
pub struct LocalFoldersPlugin;

#[cfg(target_arch = "wasm32")]
wallpaper_plugin_sdk::export_source_plugin!(LocalFoldersPlugin);

impl SourcePlugin for LocalFoldersPlugin {
    fn manifest(&self) -> PluginManifest {
        PluginManifest::new(
            "org.wallpaper.source.local-folders",
            "Local folders",
            env!("CARGO_PKG_VERSION"),
            "Wallpaper contributors",
            "User-defined local sources with any number of folders",
            [] as [&str; 0],
        )
    }

    fn config_schema(&self) -> ConfigSchema {
        ConfigSchema::default()
    }

    fn config_ui_schema(&self) -> ConfigUiSchema {
        ConfigUiSchema::default()
    }

    fn capabilities(&self) -> SourceCapabilities {
        SourceCapabilities {
            local_folders: true,
            ..SourceCapabilities::default()
        }
    }

    fn validate_config(
        &self,
        _config: &BTreeMap<String, serde_json::Value>,
    ) -> Result<(), PluginError> {
        Ok(())
    }

    fn build_list_request(&self, _request: &SourceRequest) -> Result<HostHttpRequest, PluginError> {
        Err(PluginError::Unsupported)
    }

    fn parse_list_response(
        &self,
        _request: &SourceRequest,
        _response: HostHttpResponse,
    ) -> Result<WallpaperPage, PluginError> {
        Err(PluginError::Unsupported)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn exposes_only_the_local_folder_capability() {
        let capabilities = LocalFoldersPlugin.capabilities();
        assert!(capabilities.local_folders);
        assert!(!capabilities.list && !capabilities.search && !capabilities.random);
    }
}
