use std::collections::BTreeMap;

use chrono::{DateTime, Duration, NaiveDate, Utc};
use serde::Deserialize;
use url::Url;
use wallpaper_plugin_sdk::{
    CardConfigItem, CardFieldWidth, ConfigField, ConfigFieldKind, ConfigSchema, ConfigUiSchema,
    ContentRating, HostHttpRequest, HostHttpResponse, HttpMethod, NetworkPolicy, NetworkScope,
    PluginError, PluginManifest, SourceCapabilities, SourcePlugin, SourceRequest, WallpaperItem,
    WallpaperPage, WallpaperVariant, ensure_success,
};

#[derive(Debug, Default)]
pub struct NasaApodPlugin;

#[cfg(target_arch = "wasm32")]
wallpaper_plugin_sdk::export_source_plugin!(NasaApodPlugin);

impl SourcePlugin for NasaApodPlugin {
    fn manifest(&self) -> PluginManifest {
        let mut manifest = PluginManifest::new(
            "org.wallpaper.source.nasa-apod",
            "NASA APOD",
            env!("CARGO_PKG_VERSION"),
            "Wallpaper contributors",
            "NASA Astronomy Picture of the Day image history",
            ["science.nasa.gov", "assets.science.nasa.gov"],
        );
        manifest.documentation_url = Url::parse("https://science.nasa.gov/apod/").ok();
        manifest.network = NetworkPolicy {
            requests_per_minute: 20,
            max_concurrent_requests: 1,
            timeout_seconds: 20,
            max_retries: 2,
        };
        manifest
    }

    fn config_schema(&self) -> ConfigSchema {
        ConfigSchema {
            version: 2,
            fields: vec![ConfigField {
                key: "history_days".into(),
                label: "History in days".into(),
                description: Some("Range ending today; capped at two years".into()),
                required: true,
                sensitive: false,
                kind: ConfigFieldKind::Number {
                    default: Some(730.0),
                },
            }],
        }
    }

    fn config_ui_schema(&self) -> ConfigUiSchema {
        ConfigUiSchema {
            card: vec![CardConfigItem::new("history_days", CardFieldWidth::Full)],
        }
    }

    fn capabilities(&self) -> SourceCapabilities {
        SourceCapabilities {
            list: true,
            random: true,
            ..Default::default()
        }
    }

    fn validate_config(
        &self,
        config: &BTreeMap<String, serde_json::Value>,
    ) -> Result<(), PluginError> {
        let days = config
            .get("history_days")
            .and_then(serde_json::Value::as_f64)
            .unwrap_or(730.0);
        if !(1.0..=730.0).contains(&days) {
            return Err(PluginError::InvalidConfig(
                "history_days must be between 1 and 730".into(),
            ));
        }
        Ok(())
    }

    fn migrate_config(
        &self,
        from_version: u32,
        mut config: BTreeMap<String, serde_json::Value>,
    ) -> Result<BTreeMap<String, serde_json::Value>, PluginError> {
        if !matches!(from_version, 1 | 2) {
            return Err(PluginError::UnsupportedConfigVersion(from_version));
        }
        // APOD Basic is public and exposes one full-size image, not the old
        // authenticated API's regular/HD pair. Do not send obsolete secrets.
        config.remove("api_key");
        config.remove("hd_only");
        self.validate_config(&config)?;
        Ok(config)
    }

    fn build_list_request(&self, request: &SourceRequest) -> Result<HostHttpRequest, PluginError> {
        self.validate_config(&request.config)?;
        let (start, end, _) = history_window(request)?;
        let mut url = Url::parse("https://science.nasa.gov/wp-json/wp/v2/apod-basic").unwrap();
        url.query_pairs_mut()
            .append_pair("date_from", &start.format("%y%m%d").to_string())
            .append_pair("date_to", &end.format("%y%m%d").to_string())
            .append_pair("per_page", &request.limit.clamp(1, 25).to_string())
            .append_pair(
                "_fields",
                "date,title,permalink,media_type,explanation,hdurl,credit,copyright",
            );
        Ok(HostHttpRequest {
            method: HttpMethod::Get,
            url,
            headers: BTreeMap::from([("Accept".into(), "application/json".into())]),
            form_fields: BTreeMap::new(),
            max_response_bytes: 2 * 1024 * 1024,
            network_scope: NetworkScope::DeclaredHost,
            credential_injections: Vec::new(),
        })
    }

    fn parse_list_response(
        &self,
        request: &SourceRequest,
        response: HostHttpResponse,
    ) -> Result<WallpaperPage, PluginError> {
        ensure_success(&response)?;
        let entries: Vec<ApodEntry> = serde_json::from_slice(&response.body)
            .map_err(|error| PluginError::InvalidResponse(error.to_string()))?;
        let items = entries
            .into_iter()
            .filter_map(ApodEntry::into_item)
            .take(usize::from(request.limit.max(1)))
            .collect();
        let (start, _, earliest) = history_window(request)?;
        Ok(WallpaperPage {
            items,
            next_cursor: (start > earliest).then(|| (start - Duration::days(1)).to_string()),
        })
    }

    fn build_random_request(
        &self,
        request: &SourceRequest,
    ) -> Result<HostHttpRequest, PluginError> {
        self.validate_config(&request.config)?;
        let (earliest, today) = history_bounds(request);
        let days = (today - earliest).num_days() as u64 + 1;
        let end = today - Duration::days((request.context.random_seed % days) as i64);
        let mut sampled = request.clone();
        sampled.cursor = Some(end.to_string());
        self.build_list_request(&sampled)
    }

    fn parse_random_response(
        &self,
        request: &SourceRequest,
        response: HostHttpResponse,
    ) -> Result<WallpaperPage, PluginError> {
        let mut page = self.parse_list_response(request, response)?;
        // The requested date window was selected using host-provided entropy.
        page.next_cursor = None;
        Ok(page)
    }
}

#[derive(Debug, Deserialize)]
struct ApodEntry {
    date: String,
    title: String,
    permalink: Url,
    media_type: String,
    #[serde(default)]
    explanation: Option<String>,
    #[serde(default)]
    hdurl: Option<String>,
    #[serde(default)]
    credit: Option<String>,
    #[serde(default)]
    copyright: Option<String>,
}

impl ApodEntry {
    fn into_item(self) -> Option<WallpaperItem> {
        if self.media_type != "image" {
            return None;
        }
        let image = Url::parse(self.hdurl.as_deref()?).ok()?;
        if image.scheme() != "https" || image.host_str().is_none() {
            return None;
        }
        let date = NaiveDate::parse_from_str(&self.date, "%Y-%m-%d").ok()?;
        let description = self
            .explanation
            .map(|html| {
                let text = plain_text(&html);
                let text = text.strip_prefix("Explanation:").unwrap_or(&text).trim();
                text.split("\n\nTomorrow's picture:")
                    .next()
                    .unwrap_or(text)
                    .trim()
                    .to_owned()
            })
            .filter(|text| !text.is_empty());
        let attribution = self
            .credit
            .filter(|credit| !credit.trim().is_empty())
            .or(self.copyright)
            .map(|html| plain_text(&html))
            .filter(|text| !text.is_empty());
        Some(WallpaperItem {
            id: self.date,
            title: Some(plain_text(&self.title)),
            description,
            author: None,
            source_page_url: self.permalink,
            license: None,
            attribution,
            published_at: date
                .and_hms_opt(0, 0, 0)
                .map(|value| DateTime::<Utc>::from_naive_utc_and_offset(value, Utc)),
            tags: vec!["astronomy".into(), "space".into()],
            content_rating: ContentRating::Safe,
            location: None,
            variants: vec![WallpaperVariant {
                url: image,
                mime_type: None,
                width: None,
                height: None,
                file_size: None,
                checksum: None,
            }],
            metadata: BTreeMap::new(),
        })
    }
}

// APOD Basic supplies small HTML fragments. Keep their text and paragraph
// boundaries; no remote markup or scripts are passed to the desktop renderer.
fn plain_text(html: &str) -> String {
    let mut output = String::new();
    let mut characters = html.chars();
    while let Some(character) = characters.next() {
        if character != '<' {
            output.push(character);
            continue;
        }
        let tag: String = characters
            .by_ref()
            .take_while(|character| *character != '>')
            .collect();
        let tag = tag.trim().to_ascii_lowercase();
        if tag.starts_with("br") || matches!(tag.as_str(), "p" | "/p" | "div" | "/div") {
            output.push('\n');
        }
    }
    let output = output.replace("&nbsp;", " ");
    let output = quick_xml::escape::unescape(&output).unwrap_or_else(|_| output.clone().into());
    output
        .lines()
        .map(|line| line.split_whitespace().collect::<Vec<_>>().join(" "))
        .collect::<Vec<_>>()
        .join("\n")
        .trim()
        .to_owned()
}

fn history_bounds(request: &SourceRequest) -> (NaiveDate, NaiveDate) {
    let days = request
        .config
        .get("history_days")
        .and_then(serde_json::Value::as_f64)
        .unwrap_or(730.0) as i64;
    let today = request.context.requested_at.date_naive();
    (today - Duration::days(days - 1), today)
}

fn history_window(
    request: &SourceRequest,
) -> Result<(NaiveDate, NaiveDate, NaiveDate), PluginError> {
    let (earliest, today) = history_bounds(request);
    let end = request
        .cursor
        .as_deref()
        .map(|cursor| {
            NaiveDate::parse_from_str(cursor, "%Y-%m-%d")
                .map_err(|_| PluginError::InvalidConfig("cursor must be YYYY-MM-DD".into()))
        })
        .unwrap_or(Ok(today))?;
    if end < earliest || end > today {
        return Err(PluginError::InvalidConfig(
            "cursor is outside the configured APOD history window".into(),
        ));
    }
    let requested_start = end - Duration::days(i64::from(request.limit.clamp(1, 25)) - 1);
    Ok((requested_start.max(earliest), end, earliest))
}

#[cfg(test)]
mod tests {
    use super::*;

    fn request() -> SourceRequest {
        SourceRequest {
            context: wallpaper_plugin_sdk::SourceExecutionContext {
                requested_at: "2026-11-22T12:00:00Z".parse().unwrap(),
                random_seed: 37,
            },
            config: BTreeMap::from([("history_days".into(), serde_json::json!(30))]),
            query: None,
            cursor: None,
            limit: 20,
        }
    }

    #[test]
    fn keeps_real_image_story_and_credits_without_html() {
        let page = NasaApodPlugin
            .parse_list_response(
                &request(),
                HostHttpResponse {
                    status: 200,
                    content_type: Some("application/json".into()),
                    body: include_bytes!("../tests/fixtures/list.json").to_vec(),
                },
            )
            .unwrap();
        assert_eq!(page.items.len(), 2);
        assert_eq!(page.items[0].variants.len(), 1);
        assert!(
            page.items[0].variants[0]
                .url
                .host_str()
                .unwrap()
                .ends_with("science.nasa.gov")
        );
        assert!(
            page.items[0]
                .description
                .as_ref()
                .unwrap()
                .starts_with("What creates")
        );
        assert!(!page.items[0].description.as_ref().unwrap().contains('<'));
        assert!(
            !page.items[0]
                .description
                .as_ref()
                .unwrap()
                .contains("Tomorrow's picture")
        );
        assert!(
            page.items[0]
                .attribution
                .as_ref()
                .unwrap()
                .contains("Matt Brealey")
        );
        assert!(
            page.items[0]
                .attribution
                .as_ref()
                .unwrap()
                .contains("Processing & License")
        );
        assert!(page.next_cursor.is_some());
    }

    #[test]
    fn uses_current_api_and_migrates_old_settings() {
        let plugin = NasaApodPlugin;
        let mut request = request();
        request
            .config
            .insert("api_key".into(), serde_json::json!("db:old:api_key"));
        request
            .config
            .insert("hd_only".into(), serde_json::json!(true));
        let migrated = plugin.migrate_config(1, request.config.clone()).unwrap();
        assert_eq!(migrated.len(), 1);
        let built = plugin.build_list_request(&request).unwrap();
        assert_eq!(built.url.host_str(), Some("science.nasa.gov"));
        assert!(built.credential_injections.is_empty());
        let query: BTreeMap<_, _> = built.url.query_pairs().collect();
        assert_eq!(query.get("date_from").unwrap(), "261103");
        assert_eq!(query.get("date_to").unwrap(), "261122");
        assert!(!query.contains_key("api_key"));
        assert_ne!(
            plugin.build_random_request(&request).unwrap().url,
            built.url
        );
        request.cursor = Some("2026-11-02".into());
        assert!(
            plugin
                .build_list_request(&request)
                .unwrap()
                .url
                .as_str()
                .contains("date_to=261102")
        );
    }

    #[test]
    fn handles_empty_page_and_http_error() {
        assert!(
            NasaApodPlugin
                .parse_list_response(
                    &request(),
                    HostHttpResponse {
                        status: 200,
                        content_type: Some("application/json".into()),
                        body: b"[]".to_vec(),
                    }
                )
                .unwrap()
                .items
                .is_empty()
        );
        assert!(matches!(
            NasaApodPlugin.parse_list_response(
                &request(),
                HostHttpResponse {
                    status: 500,
                    content_type: None,
                    body: Vec::new(),
                }
            ),
            Err(PluginError::HttpStatus(500))
        ));
    }
}
