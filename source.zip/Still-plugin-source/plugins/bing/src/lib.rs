use std::collections::BTreeMap;

use chrono::{DateTime, NaiveDate, Utc};
use serde::Deserialize;
use url::Url;
use wallpaper_plugin_sdk::{
    CardConfigItem, CardFieldWidth, ConfigField, ConfigFieldKind, ConfigSchema, ConfigUiSchema,
    ContentRating, HostHttpRequest, HostHttpResponse, HttpMethod, License, NetworkPolicy,
    NetworkScope, PluginError, PluginManifest, SelectOption, SourceCapabilities, SourcePlugin,
    SourceRequest, WallpaperItem, WallpaperPage, WallpaperVariant, ensure_success,
};

#[derive(Debug, Default)]
pub struct BingPlugin;

#[cfg(target_arch = "wasm32")]
wallpaper_plugin_sdk::export_source_plugin!(BingPlugin);

impl SourcePlugin for BingPlugin {
    fn manifest(&self) -> PluginManifest {
        let mut manifest = PluginManifest::new(
            "org.wallpaper.source.bing",
            "Bing",
            env!("CARGO_PKG_VERSION"),
            "Wallpaper contributors",
            "Bing daily wallpaper with regional metadata and UHD variants",
            ["www.bing.com"],
        );
        manifest.documentation_url =
            Url::parse("https://www.microsoft.com/bing/bing-wallpaper").ok();
        manifest.network = NetworkPolicy {
            requests_per_minute: 6,
            max_concurrent_requests: 1,
            timeout_seconds: 15,
            max_retries: 2,
        };
        manifest
    }

    fn config_schema(&self) -> ConfigSchema {
        ConfigSchema {
            version: 1,
            fields: vec![
                ConfigField {
                    key: "market".into(),
                    label: "Market".into(),
                    description: Some("Bing locale such as zh-CN or en-US".into()),
                    required: true,
                    sensitive: false,
                    kind: ConfigFieldKind::Text {
                        default: Some("en-US".into()),
                    },
                },
                ConfigField {
                    key: "quality".into(),
                    label: "Quality".into(),
                    description: None,
                    required: true,
                    sensitive: false,
                    kind: ConfigFieldKind::Select {
                        options: vec![
                            SelectOption {
                                value: "uhd".into(),
                                label: "UHD".into(),
                            },
                            SelectOption {
                                value: "1920x1080".into(),
                                label: "1920 × 1080".into(),
                            },
                        ],
                    },
                },
            ],
        }
    }

    fn config_ui_schema(&self) -> ConfigUiSchema {
        ConfigUiSchema {
            card: vec![
                CardConfigItem::new("market", CardFieldWidth::Half),
                CardConfigItem::new("quality", CardFieldWidth::Half),
            ],
        }
    }

    fn capabilities(&self) -> SourceCapabilities {
        SourceCapabilities {
            list: true,
            ..Default::default()
        }
    }

    fn validate_config(
        &self,
        config: &BTreeMap<String, serde_json::Value>,
    ) -> Result<(), PluginError> {
        let market = config
            .get("market")
            .and_then(serde_json::Value::as_str)
            .unwrap_or("en-US");
        let bytes = market.as_bytes();
        if bytes.len() != 5
            || bytes[2] != b'-'
            || !bytes[..2].iter().all(u8::is_ascii_alphabetic)
            || !bytes[3..].iter().all(u8::is_ascii_alphabetic)
        {
            return Err(PluginError::InvalidConfig(
                "market must look like en-US or zh-CN".into(),
            ));
        }
        Ok(())
    }

    fn build_list_request(&self, request: &SourceRequest) -> Result<HostHttpRequest, PluginError> {
        self.validate_config(&request.config)?;
        let offset = archive_offset(request)?;
        let market = request
            .config
            .get("market")
            .and_then(serde_json::Value::as_str)
            .unwrap_or("en-US");
        let mut url = Url::parse("https://www.bing.com/HPImageArchive.aspx").unwrap();
        url.query_pairs_mut()
            .append_pair("format", "js")
            .append_pair("idx", &offset.to_string())
            .append_pair("n", &request.limit.clamp(1, 8).to_string())
            .append_pair("mkt", market);
        Ok(HostHttpRequest {
            method: HttpMethod::Get,
            url,
            headers: BTreeMap::from([("Accept".into(), "application/json".into())]),
            form_fields: BTreeMap::new(),
            max_response_bytes: 512 * 1024,
            network_scope: NetworkScope::DeclaredHost,
            credential_injections: Vec::new(),
        })
    }

    fn parse_list_response(
        &self,
        request: &SourceRequest,
        response: HostHttpResponse,
    ) -> Result<WallpaperPage, PluginError> {
        ensure_success(&response)?;
        let payload: BingResponse = serde_json::from_slice(&response.body)
            .map_err(|error| PluginError::InvalidResponse(error.to_string()))?;
        let quality = request
            .config
            .get("quality")
            .and_then(serde_json::Value::as_str)
            .unwrap_or("uhd");
        let next = archive_offset(request)? + payload.images.len().min(8) as u8;
        let has_more = payload.images.len() >= usize::from(request.limit.clamp(1, 8)) && next < 8;
        let items = payload
            .images
            .into_iter()
            .filter_map(|image| image.into_item(quality).ok())
            .collect();
        Ok(WallpaperPage {
            items,
            next_cursor: has_more.then(|| next.to_string()),
        })
    }
}

fn archive_offset(request: &SourceRequest) -> Result<u8, PluginError> {
    request
        .cursor
        .as_deref()
        .unwrap_or("0")
        .parse::<u8>()
        .ok()
        .filter(|offset| *offset < 8)
        .ok_or_else(|| {
            PluginError::InvalidConfig("Bing archive cursor must be between 0 and 7".into())
        })
}

#[derive(Debug, Deserialize)]
struct BingResponse {
    images: Vec<BingImage>,
}

#[derive(Debug, Deserialize)]
struct BingImage {
    startdate: String,
    #[serde(default)]
    title: Option<String>,
    urlbase: String,
    copyright: String,
    copyrightlink: String,
}

impl BingImage {
    fn into_item(self, quality: &str) -> Result<WallpaperItem, url::ParseError> {
        let base = Url::parse("https://www.bing.com")?;
        let uhd = base.join(&format!("{}_UHD.jpg", self.urlbase))?;
        let hd = base.join(&format!("{}_1920x1080.jpg", self.urlbase))?;
        let source_page_url = base.join(&self.copyrightlink)?;
        let published_at = NaiveDate::parse_from_str(&self.startdate, "%Y%m%d")
            .ok()
            .and_then(|date| date.and_hms_opt(0, 0, 0))
            .map(|date| DateTime::<Utc>::from_naive_utc_and_offset(date, Utc));
        let variants = if quality == "1920x1080" {
            vec![variant(hd, Some(1920), Some(1080))]
        } else {
            vec![
                variant(uhd, None, None),
                variant(hd, Some(1920), Some(1080)),
            ]
        };
        Ok(WallpaperItem {
            id: self.startdate,
            title: self
                .title
                .or_else(|| self.copyright.split(" (").next().map(ToOwned::to_owned)),
            description: Some(self.copyright.clone()),
            author: None,
            source_page_url,
            license: Some(License {
                name: "Bing image copyright notice".into(),
                url: None,
            }),
            attribution: Some(self.copyright),
            published_at,
            tags: Vec::new(),
            content_rating: ContentRating::Safe,
            location: None,
            variants,
            metadata: BTreeMap::new(),
        })
    }
}

fn variant(url: Url, width: Option<u32>, height: Option<u32>) -> WallpaperVariant {
    WallpaperVariant {
        url,
        mime_type: Some("image/jpeg".into()),
        width,
        height,
        file_size: None,
        checksum: None,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn request() -> SourceRequest {
        SourceRequest {
            context: Default::default(),
            config: BTreeMap::from([
                ("market".into(), serde_json::json!("en-US")),
                ("quality".into(), serde_json::json!("uhd")),
            ]),
            query: None,
            cursor: None,
            limit: 8,
        }
    }

    #[test]
    fn parses_daily_image_and_uhd_variant() {
        let body = include_bytes!("../tests/fixtures/list.json");
        let page = BingPlugin
            .parse_list_response(
                &request(),
                HostHttpResponse {
                    status: 200,
                    content_type: Some("application/json".into()),
                    body: body.to_vec(),
                },
            )
            .unwrap();
        assert_eq!(page.items[0].id, "20260805");
        assert!(page.items[0].variants[0].url.as_str().contains("_UHD.jpg"));
    }

    #[test]
    fn handles_empty_archive_and_http_error() {
        let empty = BingPlugin
            .parse_list_response(
                &request(),
                HostHttpResponse {
                    status: 200,
                    content_type: Some("application/json".into()),
                    body: br#"{"images":[]}"#.to_vec(),
                },
            )
            .unwrap();
        assert!(empty.items.is_empty());
        assert!(matches!(
            BingPlugin.parse_list_response(
                &request(),
                HostHttpResponse {
                    status: 429,
                    content_type: None,
                    body: Vec::new(),
                }
            ),
            Err(PluginError::HttpStatus(429))
        ));
    }
}
