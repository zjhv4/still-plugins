use std::collections::BTreeMap;

use chrono::{DateTime, Utc};
use serde::{Deserialize, Deserializer};
use url::Url;
use wallpaper_plugin_sdk::{
    Author, CardConfigItem, CardFieldWidth, ConfigField, ConfigFieldKind, ConfigSchema,
    ConfigUiSchema, ContentRating, CredentialInjection, CredentialTarget, HostHttpRequest,
    HostHttpResponse, HttpMethod, NetworkPolicy, NetworkScope, PluginError, PluginManifest,
    SelectOption, SourceCapabilities, SourcePlugin, SourceRequest, WallpaperItem, WallpaperPage,
    WallpaperVariant, ensure_success, page_number,
};

#[derive(Debug, Default)]
pub struct WallhavenPlugin;

#[cfg(target_arch = "wasm32")]
wallpaper_plugin_sdk::export_source_plugin!(WallhavenPlugin);

impl SourcePlugin for WallhavenPlugin {
    fn manifest(&self) -> PluginManifest {
        let mut manifest = PluginManifest::new(
            "org.wallpaper.source.wallhaven",
            "Wallhaven",
            env!("CARGO_PKG_VERSION"),
            "Wallpaper contributors",
            "Search Wallhaven with explicit category, purity and resolution filters",
            ["wallhaven.cc", "w.wallhaven.cc", "th.wallhaven.cc"],
        );
        manifest.documentation_url = Url::parse("https://wallhaven.cc/help/api").ok();
        manifest.network = NetworkPolicy {
            requests_per_minute: 45,
            max_concurrent_requests: 2,
            timeout_seconds: 20,
            max_retries: 2,
        };
        manifest
    }

    fn config_schema(&self) -> ConfigSchema {
        ConfigSchema {
            version: 1,
            fields: vec![
                text(
                    "query",
                    "Keywords, tag query or Wallhaven search URL",
                    Some("landscape"),
                ),
                select(
                    "sorting",
                    "Sorting",
                    &[
                        ("toplist", "Top"),
                        ("date_added", "Latest"),
                        ("random", "Random"),
                        ("relevance", "Relevance"),
                        ("views", "Views"),
                        ("favorites", "Favorites"),
                        ("hot", "Hot"),
                    ],
                ),
                select(
                    "categories",
                    "Categories",
                    &[
                        ("111", "All"),
                        ("100", "General"),
                        ("010", "Anime"),
                        ("001", "People"),
                    ],
                ),
                select(
                    "purity",
                    "Purity",
                    &[("100", "Safe"), ("110", "Safe + Sketchy"), ("111", "All")],
                ),
                text("atleast", "Minimum resolution", Some("1920x1080")),
                ConfigField {
                    key: "api_key".into(),
                    label: "API key".into(),
                    description: Some(
                        "Required for NSFW results; stored as a secret reference".into(),
                    ),
                    required: false,
                    sensitive: true,
                    kind: ConfigFieldKind::SecretReference,
                },
            ],
        }
    }

    fn config_ui_schema(&self) -> ConfigUiSchema {
        ConfigUiSchema {
            card: vec![
                CardConfigItem::new("query", CardFieldWidth::Full),
                CardConfigItem::new("sorting", CardFieldWidth::Half),
                CardConfigItem::new("categories", CardFieldWidth::Half),
                CardConfigItem::new("purity", CardFieldWidth::Half),
                CardConfigItem::new("atleast", CardFieldWidth::Half),
                CardConfigItem::new("api_key", CardFieldWidth::Full),
            ],
        }
    }

    fn capabilities(&self) -> SourceCapabilities {
        SourceCapabilities {
            list: true,
            search: true,
            random: true,
            ..Default::default()
        }
    }

    fn validate_config(
        &self,
        config: &BTreeMap<String, serde_json::Value>,
    ) -> Result<(), PluginError> {
        search_parameters(config, None).map(|_| ())
    }

    fn build_list_request(&self, request: &SourceRequest) -> Result<HostHttpRequest, PluginError> {
        self.build_request(request, request.query.as_deref(), false)
    }

    fn parse_list_response(
        &self,
        request: &SourceRequest,
        response: HostHttpResponse,
    ) -> Result<WallpaperPage, PluginError> {
        parse_response(request, response)
    }

    fn build_search_request(
        &self,
        request: &SourceRequest,
    ) -> Result<HostHttpRequest, PluginError> {
        self.build_request(request, request.query.as_deref(), false)
    }

    fn parse_search_response(
        &self,
        request: &SourceRequest,
        response: HostHttpResponse,
    ) -> Result<WallpaperPage, PluginError> {
        parse_response(request, response)
    }

    fn build_random_request(
        &self,
        request: &SourceRequest,
    ) -> Result<HostHttpRequest, PluginError> {
        self.build_request(request, request.query.as_deref(), true)
    }

    fn parse_random_response(
        &self,
        request: &SourceRequest,
        response: HostHttpResponse,
    ) -> Result<WallpaperPage, PluginError> {
        parse_response(request, response)
    }
}

impl WallhavenPlugin {
    fn build_request(
        &self,
        request: &SourceRequest,
        query_override: Option<&str>,
        force_random: bool,
    ) -> Result<HostHttpRequest, PluginError> {
        self.validate_config(&request.config)?;
        let page = page_number(request.cursor.as_deref())?;
        let mut url = Url::parse("https://wallhaven.cc/api/v1/search").unwrap();
        let mut parameters = search_parameters(&request.config, query_override)?;
        if force_random {
            parameters.insert("sorting".into(), "random".into());
            parameters.remove("seed");
        }
        url.query_pairs_mut()
            .extend_pairs(parameters)
            .append_pair("page", &page.to_string());
        Ok(HostHttpRequest {
            method: HttpMethod::Get,
            url,
            headers: BTreeMap::from([("Accept".into(), "application/json".into())]),
            form_fields: BTreeMap::new(),
            max_response_bytes: 4 * 1024 * 1024,
            network_scope: NetworkScope::DeclaredHost,
            credential_injections: vec![CredentialInjection {
                config_key: "api_key".into(),
                target: CredentialTarget::Header {
                    name: "X-API-Key".into(),
                    prefix: String::new(),
                },
                required: false,
            }],
        })
    }
}

fn search_parameters(
    config: &BTreeMap<String, serde_json::Value>,
    query_override: Option<&str>,
) -> Result<BTreeMap<String, String>, PluginError> {
    let mut parameters: BTreeMap<String, String> = [
        ("sorting", "toplist"),
        ("categories", "111"),
        ("purity", "100"),
        ("atleast", "1920x1080"),
    ]
    .into_iter()
    .map(|(key, fallback)| (key.into(), value(config, key, fallback).into()))
    .collect();
    let query = query_override
        .unwrap_or_else(|| value(config, "query", ""))
        .trim();
    if query.contains("://") {
        let invalid = || PluginError::InvalidConfig("Use a Wallhaven search or tag URL".into());
        let input = Url::parse(query).map_err(|_| invalid())?;
        if input.scheme() != "https"
            || input.host_str() != Some("wallhaven.cc")
            || !input.username().is_empty()
            || input.password().is_some()
            || input.port().is_some()
        {
            return Err(invalid());
        }
        if input.path().trim_end_matches('/') == "/search" {
            parameters.insert("q".into(), String::new());
            for (key, val) in input.query_pairs() {
                if matches!(
                    key.as_ref(),
                    "q" | "sorting"
                        | "categories"
                        | "purity"
                        | "atleast"
                        | "resolutions"
                        | "ratios"
                        | "order"
                        | "topRange"
                        | "colors"
                        | "seed"
                ) {
                    parameters.insert(key.into_owned(), val.into_owned());
                }
            }
            if parameters.contains_key("resolutions") {
                parameters.remove("atleast");
            }
        } else if let Some(tag) = input.path().trim_end_matches('/').strip_prefix("/tag/") {
            if tag.is_empty() || !tag.bytes().all(|byte| byte.is_ascii_digit()) {
                return Err(invalid());
            }
            parameters.insert("q".into(), format!("id:{tag}"));
        } else {
            return Err(invalid());
        }
    } else {
        parameters.insert("q".into(), query.into());
    }
    for key in ["purity", "categories"] {
        let mask = &parameters[key];
        if mask.len() != 3 || mask == "000" || !mask.bytes().all(|byte| matches!(byte, b'0' | b'1'))
        {
            return Err(PluginError::InvalidConfig(format!("invalid {key} mask")));
        }
    }
    if !matches!(
        parameters["sorting"].as_str(),
        "date_added" | "relevance" | "random" | "views" | "favorites" | "toplist" | "hot"
    ) {
        return Err(PluginError::InvalidConfig("invalid sorting mode".into()));
    }
    Ok(parameters)
}

#[derive(Debug, Deserialize)]
struct SearchResponse {
    data: Vec<WallhavenEntry>,
    meta: SearchMeta,
}

#[derive(Debug, Deserialize)]
struct SearchMeta {
    current_page: u32,
    last_page: u32,
}

#[derive(Debug, Deserialize)]
struct WallhavenEntry {
    id: String,
    url: Url,
    path: Url,
    dimension_x: u32,
    dimension_y: u32,
    file_size: u64,
    file_type: String,
    purity: String,
    category: String,
    #[serde(default, deserialize_with = "deserialize_wallhaven_time")]
    created_at: Option<DateTime<Utc>>,
    #[serde(default)]
    uploader: Option<Uploader>,
    #[serde(default)]
    tags: Vec<Tag>,
}

fn deserialize_wallhaven_time<'de, D>(deserializer: D) -> Result<Option<DateTime<Utc>>, D::Error>
where
    D: Deserializer<'de>,
{
    let value = Option::<String>::deserialize(deserializer)?;
    value
        .map(|value| {
            DateTime::parse_from_rfc3339(&value)
                .map(|date| date.with_timezone(&Utc))
                .or_else(|_| {
                    chrono::NaiveDateTime::parse_from_str(&value, "%Y-%m-%d %H:%M:%S")
                        .map(|date| date.and_utc())
                })
                .map_err(serde::de::Error::custom)
        })
        .transpose()
}

#[derive(Debug, Deserialize)]
struct Uploader {
    username: String,
}

#[derive(Debug, Deserialize)]
struct Tag {
    name: String,
}

fn parse_response(
    request: &SourceRequest,
    response: HostHttpResponse,
) -> Result<WallpaperPage, PluginError> {
    ensure_success(&response)?;
    let payload: SearchResponse = serde_json::from_slice(&response.body)
        .map_err(|error| PluginError::InvalidResponse(error.to_string()))?;
    let next_cursor = (payload.meta.current_page < payload.meta.last_page)
        .then(|| (payload.meta.current_page + 1).to_string());
    let items = payload
        .data
        .into_iter()
        .take(usize::from(request.limit.max(1)))
        .map(|entry| WallpaperItem {
            id: entry.id,
            title: entry.tags.first().map(|tag| tag.name.clone()),
            description: Some(entry.category),
            author: entry.uploader.map(|uploader| Author {
                name: uploader.username,
                url: None,
            }),
            source_page_url: entry.url,
            license: None,
            attribution: Some("Source: Wallhaven".into()),
            published_at: entry.created_at,
            tags: entry.tags.into_iter().map(|tag| tag.name).collect(),
            content_rating: match entry.purity.as_str() {
                "sfw" => ContentRating::Safe,
                "sketchy" => ContentRating::Sketchy,
                "nsfw" => ContentRating::Adult,
                _ => ContentRating::Unknown,
            },
            location: None,
            variants: vec![WallpaperVariant {
                url: entry.path,
                mime_type: Some(entry.file_type),
                width: Some(entry.dimension_x),
                height: Some(entry.dimension_y),
                file_size: Some(entry.file_size),
                checksum: None,
            }],
            metadata: BTreeMap::new(),
        })
        .collect();
    Ok(WallpaperPage { items, next_cursor })
}

fn value<'a>(
    config: &'a BTreeMap<String, serde_json::Value>,
    key: &str,
    default: &'a str,
) -> &'a str {
    config
        .get(key)
        .and_then(serde_json::Value::as_str)
        .unwrap_or(default)
}

fn text(key: &str, label: &str, default: Option<&str>) -> ConfigField {
    ConfigField {
        key: key.into(),
        label: label.into(),
        description: None,
        required: false,
        sensitive: false,
        kind: ConfigFieldKind::Text {
            default: default.map(Into::into),
        },
    }
}

fn select(key: &str, label: &str, values: &[(&str, &str)]) -> ConfigField {
    ConfigField {
        key: key.into(),
        label: label.into(),
        description: None,
        required: true,
        sensitive: false,
        kind: ConfigFieldKind::Select {
            options: values
                .iter()
                .map(|(value, label)| SelectOption {
                    value: (*value).into(),
                    label: (*label).into(),
                })
                .collect(),
        },
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn request() -> SourceRequest {
        SourceRequest {
            context: Default::default(),
            config: BTreeMap::new(),
            query: Some("mountains".into()),
            cursor: None,
            limit: 24,
        }
    }

    #[test]
    fn search_url_preserves_filters_but_uses_host_cursor_and_credentials() {
        let mut req = request();
        req.query = Some("https://wallhaven.cc/search?q=id%3A42&categories=010&purity=100&sorting=favorites&order=desc&resolutions=3840x2160&ratios=16x9&colors=abcdef&topRange=1M&page=99&apikey=never-copy".into());
        req.cursor = Some("2".into());
        let built = WallhavenPlugin.build_list_request(&req).unwrap();
        let pairs: BTreeMap<_, _> = built.url.query_pairs().into_owned().collect();
        assert_eq!(pairs["q"], "id:42");
        assert_eq!(pairs["categories"], "010");
        assert_eq!(pairs["sorting"], "favorites");
        assert_eq!(pairs["resolutions"], "3840x2160");
        assert_eq!(pairs["page"], "2");
        assert!(!pairs.contains_key("apikey"));
        assert!(!pairs.contains_key("atleast"));
        let random = WallhavenPlugin.build_random_request(&req).unwrap();
        assert_eq!(
            random
                .url
                .query_pairs()
                .find(|(key, _)| key == "sorting")
                .unwrap()
                .1,
            "random"
        );
    }

    #[test]
    fn tag_urls_and_invalid_search_urls_are_distinguished() {
        let mut req = request();
        req.query = Some("https://wallhaven.cc/tag/42".into());
        let built = WallhavenPlugin.build_search_request(&req).unwrap();
        assert_eq!(
            built
                .url
                .query_pairs()
                .find(|(key, _)| key == "q")
                .unwrap()
                .1,
            "id:42"
        );
        for input in [
            "https://wallhaven.cc/w/abc123",
            "https://wallhaven.cc.evil.test/search?q=test",
            "https://wallhaven.cc/search?categories=000",
            "https://wallhaven.cc/search?sorting=unknown",
        ] {
            req.query = Some(input.into());
            assert!(WallhavenPlugin.build_list_request(&req).is_err(), "{input}");
        }
    }

    #[test]
    fn parses_pagination_rating_and_dimensions() {
        let body = include_bytes!("../tests/fixtures/list.json");
        let page = WallhavenPlugin
            .parse_list_response(
                &request(),
                HostHttpResponse {
                    status: 200,
                    content_type: Some("application/json".into()),
                    body: body.to_vec(),
                },
            )
            .unwrap();
        assert_eq!(page.next_cursor.as_deref(), Some("2"));
        assert_eq!(page.items[0].content_rating, ContentRating::Safe);
        assert_eq!(page.items[0].variants[0].width, Some(3840));
    }

    #[test]
    fn handles_empty_page_and_http_error() {
        let empty = WallhavenPlugin
            .parse_list_response(
                &request(),
                HostHttpResponse {
                    status: 200,
                    content_type: Some("application/json".into()),
                    body: br#"{"data":[],"meta":{"current_page":1,"last_page":1}}"#.to_vec(),
                },
            )
            .unwrap();
        assert!(empty.items.is_empty());
        assert!(matches!(
            WallhavenPlugin.parse_list_response(
                &request(),
                HostHttpResponse {
                    status: 429,
                    content_type: None,
                    body: Vec::new(),
                }
            ),
            Err(PluginError::HttpStatus(429))
        ));
    }
}
