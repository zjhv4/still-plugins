use std::collections::BTreeMap;

use chrono::{DateTime, Utc};
use serde::Deserialize;
use url::Url;
use wallpaper_plugin_sdk::{
    Author, CardConfigItem, CardFieldWidth, ConfigField, ConfigFieldKind, ConfigSchema,
    ConfigUiSchema, ContentRating, CredentialInjection, CredentialTarget, HostHttpRequest,
    HostHttpResponse, HttpMethod, License, Location, NetworkPolicy, NetworkScope, PluginError,
    PluginManifest, SelectOption, SourceCapabilities, SourcePlugin, SourceRequest, WallpaperItem,
    WallpaperPage, WallpaperVariant, ensure_success, page_number,
};

#[derive(Debug, Default)]
pub struct UnsplashPlugin;

#[cfg(target_arch = "wasm32")]
wallpaper_plugin_sdk::export_source_plugin!(UnsplashPlugin);

impl SourcePlugin for UnsplashPlugin {
    fn manifest(&self) -> PluginManifest {
        let mut manifest = PluginManifest::new(
            "org.wallpaper.source.unsplash",
            "Unsplash",
            env!("CARGO_PKG_VERSION"),
            "Wallpaper contributors",
            "Official Unsplash API client for random, search, user, collection and topic photos",
            ["api.unsplash.com", "images.unsplash.com", "unsplash.com"],
        );
        manifest.documentation_url = Url::parse("https://unsplash.com/documentation").ok();
        manifest.network = NetworkPolicy {
            requests_per_minute: 40,
            max_concurrent_requests: 2,
            timeout_seconds: 20,
            max_retries: 1,
        };
        manifest
    }

    fn config_schema(&self) -> ConfigSchema {
        ConfigSchema {
            version: 1,
            fields: vec![
                ConfigField {
                    key: "mode".into(),
                    label: "Source mode".into(),
                    description: Some("Page URLs choose their matching resource automatically; all modes use API v1".into()),
                    required: true,
                    sensitive: false,
                    kind: ConfigFieldKind::Select {
                        options: [
                            ("latest", "Latest"),
                            ("random", "Random"),
                            ("search", "Search"),
                            ("user", "User"),
                            ("collection", "Collection"),
                            ("topic", "Topic"),
                        ]
                        .into_iter()
                        .map(|(value, label)| SelectOption {
                            value: value.into(),
                            label: label.into(),
                        })
                        .collect(),
                    },
                },
                ConfigField {
                    key: "identifier".into(),
                    label: "Query or identifier".into(),
                    description: Some("Keyword, username, collection ID, topic slug, or corresponding Unsplash page URL".into()),
                    required: false,
                    sensitive: false,
                    kind: ConfigFieldKind::Text {
                        default: Some("nature".into()),
                    },
                },
                ConfigField {
                    key: "content_filter".into(),
                    label: "Content filter".into(),
                    description: None,
                    required: true,
                    sensitive: false,
                    kind: ConfigFieldKind::Select {
                        options: vec![
                            SelectOption {
                                value: "high".into(),
                                label: "High".into(),
                            },
                            SelectOption {
                                value: "low".into(),
                                label: "Low".into(),
                            },
                        ],
                    },
                },
                ConfigField {
                    key: "access_key".into(),
                    label: "Unsplash access key".into(),
                    description: Some(
                        "Stored by the host and injected as a Client-ID header".into(),
                    ),
                    required: true,
                    sensitive: true,
                    kind: ConfigFieldKind::SecretReference,
                },
            ],
        }
    }

    fn config_ui_schema(&self) -> ConfigUiSchema {
        ConfigUiSchema {
            card: vec![
                CardConfigItem::new("mode", CardFieldWidth::Half),
                CardConfigItem::new("identifier", CardFieldWidth::Half),
                CardConfigItem::new("content_filter", CardFieldWidth::Half),
                CardConfigItem::new("access_key", CardFieldWidth::Full),
            ],
        }
    }

    fn capabilities(&self) -> SourceCapabilities {
        SourceCapabilities {
            list: true,
            search: true,
            random: true,
            ..Default::default()
        }
    }

    fn validate_config(
        &self,
        config: &BTreeMap<String, serde_json::Value>,
    ) -> Result<(), PluginError> {
        let mode = value(config, "mode", "latest");
        if !matches!(
            mode,
            "latest" | "random" | "search" | "user" | "collection" | "topic"
        ) {
            return Err(PluginError::InvalidConfig(
                "unsupported Unsplash mode".into(),
            ));
        }
        if matches!(mode, "search" | "user" | "collection" | "topic")
            && value(config, "identifier", "").trim().is_empty()
        {
            return Err(PluginError::InvalidConfig(
                "identifier is required for this mode".into(),
            ));
        }
        if value(config, "access_key", "").trim().is_empty() {
            return Err(PluginError::InvalidConfig(
                "access_key secret reference is required".into(),
            ));
        }
        if !matches!(value(config, "content_filter", "high"), "high" | "low") {
            return Err(PluginError::InvalidConfig(
                "unsupported content filter".into(),
            ));
        }
        selection(config, None)?;
        Ok(())
    }

    fn build_list_request(&self, request: &SourceRequest) -> Result<HostHttpRequest, PluginError> {
        self.build_request(request, None, false)
    }

    fn parse_list_response(
        &self,
        request: &SourceRequest,
        response: HostHttpResponse,
    ) -> Result<WallpaperPage, PluginError> {
        parse_response(request, response, None, false)
    }

    fn build_search_request(
        &self,
        request: &SourceRequest,
    ) -> Result<HostHttpRequest, PluginError> {
        self.build_request(request, request.query.as_deref(), false)
    }

    fn parse_search_response(
        &self,
        request: &SourceRequest,
        response: HostHttpResponse,
    ) -> Result<WallpaperPage, PluginError> {
        parse_response(request, response, request.query.as_deref(), false)
    }

    fn build_random_request(
        &self,
        request: &SourceRequest,
    ) -> Result<HostHttpRequest, PluginError> {
        self.build_request(request, request.query.as_deref(), true)
    }

    fn parse_random_response(
        &self,
        request: &SourceRequest,
        response: HostHttpResponse,
    ) -> Result<WallpaperPage, PluginError> {
        parse_response(request, response, request.query.as_deref(), true)
    }

    fn build_download_event_request(
        &self,
        item: &WallpaperItem,
        config: &BTreeMap<String, serde_json::Value>,
    ) -> Result<Option<HostHttpRequest>, PluginError> {
        self.validate_config(config)?;
        let url = item
            .metadata
            .get("unsplash.download_location")
            .and_then(serde_json::Value::as_str)
            .ok_or_else(|| {
                PluginError::InvalidResponse("missing Unsplash download location".into())
            })?;
        let url =
            Url::parse(url).map_err(|error| PluginError::InvalidResponse(error.to_string()))?;
        Ok(Some(HostHttpRequest {
            method: HttpMethod::Get,
            url,
            headers: BTreeMap::from([
                ("Accept".into(), "application/json".into()),
                ("Accept-Version".into(), "v1".into()),
            ]),
            form_fields: BTreeMap::new(),
            max_response_bytes: 512 * 1024,
            network_scope: NetworkScope::DeclaredHost,
            credential_injections: vec![CredentialInjection {
                config_key: "access_key".into(),
                target: CredentialTarget::Header {
                    name: "Authorization".into(),
                    prefix: "Client-ID ".into(),
                },
                required: true,
            }],
        }))
    }
}

impl UnsplashPlugin {
    fn build_request(
        &self,
        request: &SourceRequest,
        query_override: Option<&str>,
        force_random: bool,
    ) -> Result<HostHttpRequest, PluginError> {
        self.validate_config(&request.config)?;
        let (mode, identifier) = selection(&request.config, query_override)?;
        let random = force_random || mode == "random";
        let path = match if random { "random" } else { mode.as_str() } {
            "random" => "/photos/random".to_owned(),
            "search" => "/search/photos".to_owned(),
            "user" => format!("/users/{identifier}/photos"),
            "collection" => format!("/collections/{identifier}/photos"),
            "topic" => format!("/topics/{identifier}/photos"),
            _ => "/photos".to_owned(),
        };
        let mut url = Url::parse("https://api.unsplash.com")
            .unwrap()
            .join(&path)
            .unwrap();
        let page = if random {
            1
        } else {
            page_number(request.cursor.as_deref())?
        };
        {
            let mut pairs = url.query_pairs_mut();
            if random {
                pairs
                    .append_pair("count", &request.limit.clamp(1, 30).to_string())
                    .append_pair(
                        "content_filter",
                        value(&request.config, "content_filter", "high"),
                    );
                if !identifier.is_empty() {
                    let filter = match mode.as_str() {
                        "user" => "username",
                        "collection" => "collections",
                        "topic" => "topics",
                        _ => "query",
                    };
                    pairs.append_pair(filter, &identifier);
                }
            } else {
                pairs
                    .append_pair("page", &page.to_string())
                    .append_pair("per_page", &request.limit.clamp(1, 30).to_string());
                if mode == "search" {
                    pairs.append_pair("query", &identifier).append_pair(
                        "content_filter",
                        value(&request.config, "content_filter", "high"),
                    );
                }
            }
        }
        Ok(HostHttpRequest {
            method: HttpMethod::Get,
            url,
            headers: BTreeMap::from([
                ("Accept".into(), "application/json".into()),
                ("Accept-Version".into(), "v1".into()),
            ]),
            form_fields: BTreeMap::new(),
            max_response_bytes: 4 * 1024 * 1024,
            network_scope: NetworkScope::DeclaredHost,
            credential_injections: vec![CredentialInjection {
                config_key: "access_key".into(),
                target: CredentialTarget::Header {
                    name: "Authorization".into(),
                    prefix: "Client-ID ".into(),
                },
                required: true,
            }],
        })
    }
}

fn selection(
    config: &BTreeMap<String, serde_json::Value>,
    query_override: Option<&str>,
) -> Result<(String, String), PluginError> {
    let mut mode = if query_override.is_some() {
        "search"
    } else {
        value(config, "mode", "latest")
    }
    .to_owned();
    let raw = query_override
        .unwrap_or_else(|| value(config, "identifier", ""))
        .trim();
    let mut identifier = raw.to_owned();
    if raw.contains("://") {
        let invalid = || {
            PluginError::InvalidConfig(
                "Use an Unsplash user, collection, topic or photo-search page URL".into(),
            )
        };
        let url = Url::parse(raw).map_err(|_| invalid())?;
        if url.scheme() != "https"
            || !matches!(url.host_str(), Some("unsplash.com" | "www.unsplash.com"))
            || !url.username().is_empty()
            || url.password().is_some()
            || url.port().is_some()
        {
            return Err(invalid());
        }
        let segments: Vec<_> = url
            .path_segments()
            .ok_or_else(invalid)?
            .filter(|part| !part.is_empty())
            .collect();
        let (kind, encoded) = match segments.as_slice() {
            [user] | [user, "photos"] if user.starts_with('@') => ("user", &user[1..]),
            ["collections", id] | ["collections", id, _] => ("collection", *id),
            ["t", slug] => ("topic", *slug),
            ["s", "photos", query] => ("search", *query),
            _ => return Err(invalid()),
        };
        mode = kind.into();
        identifier = percent_encoding::percent_decode_str(encoded)
            .decode_utf8()
            .map_err(|_| invalid())?
            .into_owned();
    } else if mode == "user" {
        identifier = identifier.trim_start_matches('@').into();
    }
    if matches!(mode.as_str(), "search" | "user" | "collection" | "topic") && identifier.is_empty()
    {
        return Err(PluginError::InvalidConfig(
            "identifier is required for this mode".into(),
        ));
    }
    if matches!(mode.as_str(), "user" | "collection" | "topic")
        && !identifier
            .bytes()
            .all(|byte| byte.is_ascii_alphanumeric() || matches!(byte, b'_' | b'-'))
    {
        return Err(PluginError::InvalidConfig(
            "identifier contains unsupported characters".into(),
        ));
    }
    Ok((mode, identifier))
}

#[derive(Debug, Deserialize)]
struct SearchEnvelope {
    results: Vec<Photo>,
    #[serde(default)]
    total_pages: Option<u32>,
}

#[derive(Debug, Deserialize)]
struct Photo {
    id: String,
    #[serde(default)]
    description: Option<String>,
    #[serde(default)]
    alt_description: Option<String>,
    width: u32,
    height: u32,
    #[serde(default)]
    created_at: Option<DateTime<Utc>>,
    urls: PhotoUrls,
    links: PhotoLinks,
    user: PhotoUser,
    #[serde(default)]
    color: Option<String>,
    #[serde(default)]
    location: Option<PhotoLocation>,
    #[serde(default)]
    tags: Vec<PhotoTag>,
}

#[derive(Debug, Deserialize)]
struct PhotoUrls {
    raw: Url,
    full: Url,
    regular: Url,
}

#[derive(Debug, Deserialize)]
struct PhotoLinks {
    html: Url,
    download_location: Url,
}

#[derive(Debug, Deserialize)]
struct PhotoUser {
    name: String,
    links: UserLinks,
}

#[derive(Debug, Deserialize)]
struct UserLinks {
    html: Url,
}

#[derive(Debug, Deserialize)]
struct PhotoLocation {
    #[serde(default)]
    country: Option<String>,
    #[serde(default)]
    position: Option<Position>,
}

#[derive(Debug, Deserialize)]
struct Position {
    #[serde(default)]
    latitude: Option<f64>,
    #[serde(default)]
    longitude: Option<f64>,
}

#[derive(Debug, Deserialize)]
struct PhotoTag {
    title: String,
}

fn parse_response(
    request: &SourceRequest,
    response: HostHttpResponse,
    query_override: Option<&str>,
    force_random: bool,
) -> Result<WallpaperPage, PluginError> {
    ensure_success(&response)?;
    let value: serde_json::Value = serde_json::from_slice(&response.body)
        .map_err(|error| PluginError::InvalidResponse(error.to_string()))?;
    let (photos, total_pages) = if value.get("results").is_some() {
        let envelope: SearchEnvelope = serde_json::from_value(value)
            .map_err(|error| PluginError::InvalidResponse(error.to_string()))?;
        (envelope.results, envelope.total_pages)
    } else if value.is_array() {
        (
            serde_json::from_value(value)
                .map_err(|error| PluginError::InvalidResponse(error.to_string()))?,
            None,
        )
    } else {
        (
            vec![
                serde_json::from_value(value)
                    .map_err(|error| PluginError::InvalidResponse(error.to_string()))?,
            ],
            None,
        )
    };
    let random = force_random || selection(&request.config, query_override)?.0 == "random";
    let current_page = if random {
        1
    } else {
        page_number(request.cursor.as_deref())?
    };
    let next_cursor = if random {
        (!photos.is_empty()).then(|| format!("random:{}", request.context.random_seed))
    } else if total_pages.is_some_and(|total| current_page < total)
        || total_pages.is_none() && photos.len() >= usize::from(request.limit.clamp(1, 30))
    {
        Some((current_page + 1).to_string())
    } else {
        None
    };
    Ok(WallpaperPage {
        items: photos.into_iter().map(Photo::into_item).collect(),
        next_cursor,
    })
}

impl Photo {
    fn into_item(self) -> WallpaperItem {
        let mut author_url = self.user.links.html;
        author_url
            .query_pairs_mut()
            .append_pair("utm_source", "wallpaper")
            .append_pair("utm_medium", "referral");
        let position = self
            .location
            .as_ref()
            .and_then(|location| location.position.as_ref());
        let location = self.location.as_ref().map(|source| Location {
            country: source.country.clone(),
            region: None,
            latitude: position.and_then(|value| value.latitude),
            longitude: position.and_then(|value| value.longitude),
        });
        let mut metadata = BTreeMap::new();
        metadata.insert(
            "unsplash.download_location".into(),
            serde_json::json!(self.links.download_location),
        );
        if let Some(color) = self.color {
            metadata.insert("unsplash.color".into(), serde_json::json!(color));
        }
        WallpaperItem {
            id: self.id,
            title: self.description.clone().or(self.alt_description.clone()),
            description: self.description.or(self.alt_description),
            author: Some(Author {
                name: self.user.name.clone(),
                url: Some(author_url),
            }),
            source_page_url: self.links.html,
            license: Some(License {
                name: "Unsplash License".into(),
                url: Url::parse("https://unsplash.com/license").ok(),
            }),
            attribution: Some(format!("Photo by {} on Unsplash", self.user.name)),
            published_at: self.created_at,
            tags: self.tags.into_iter().map(|tag| tag.title).collect(),
            content_rating: ContentRating::Safe,
            location,
            variants: vec![
                unsplash_variant(self.urls.raw, self.width, self.height),
                unsplash_variant(self.urls.full, self.width, self.height),
                WallpaperVariant {
                    url: self.urls.regular,
                    mime_type: Some("image/jpeg".into()),
                    width: Some(1080),
                    height: None,
                    file_size: None,
                    checksum: None,
                },
            ],
            metadata,
        }
    }
}

fn unsplash_variant(url: Url, width: u32, height: u32) -> WallpaperVariant {
    WallpaperVariant {
        url,
        mime_type: Some("image/jpeg".into()),
        width: Some(width),
        height: Some(height),
        file_size: None,
        checksum: None,
    }
}

fn value<'a>(
    config: &'a BTreeMap<String, serde_json::Value>,
    key: &str,
    default: &'a str,
) -> &'a str {
    config
        .get(key)
        .and_then(serde_json::Value::as_str)
        .unwrap_or(default)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn request() -> SourceRequest {
        SourceRequest {
            context: Default::default(),
            config: BTreeMap::from([
                ("mode".into(), serde_json::json!("search")),
                ("identifier".into(), serde_json::json!("nature")),
                ("content_filter".into(), serde_json::json!("high")),
                ("access_key".into(), serde_json::json!("secret:unsplash")),
            ]),
            query: None,
            cursor: None,
            limit: 20,
        }
    }

    #[test]
    fn page_urls_select_the_api_resource_without_leaking_query_parameters() {
        for (input, path, query) in [
            (
                "https://unsplash.com/@ada/photos?client_id=not-a-credential",
                "/users/ada/photos",
                None,
            ),
            (
                "https://unsplash.com/collections/123/nature",
                "/collections/123/photos",
                None,
            ),
            (
                "https://unsplash.com/t/nature",
                "/topics/nature/photos",
                None,
            ),
            (
                "https://unsplash.com/s/photos/blue%20sky",
                "/search/photos",
                Some("blue sky"),
            ),
        ] {
            let mut req = request();
            req.config
                .insert("identifier".into(), serde_json::json!(input));
            req.cursor = Some("2".into());
            let built = UnsplashPlugin.build_list_request(&req).unwrap();
            assert_eq!(built.url.path(), path);
            let pairs: BTreeMap<_, _> = built.url.query_pairs().into_owned().collect();
            assert_eq!(pairs.get("query").map(String::as_str), query);
            assert_eq!(pairs["page"], "2");
            assert!(!pairs.contains_key("client_id"));
        }
        for input in [
            "https://unsplash.com/photos/single-picture",
            "https://unsplash.com.evil.test/@ada",
            "https://unsplash.com:8443/@ada",
            "https://unsplash.com/@a%2Fb",
        ] {
            let mut req = request();
            req.config
                .insert("identifier".into(), serde_json::json!(input));
            assert!(UnsplashPlugin.build_list_request(&req).is_err(), "{input}");
        }
    }

    #[test]
    fn random_operation_keeps_its_endpoint_filters_and_non_numeric_cursor() {
        let mut req = request();
        req.query = Some("mountains".into());
        req.cursor = Some("random:42".into());
        let built = UnsplashPlugin.build_random_request(&req).unwrap();
        assert_eq!(built.url.path(), "/photos/random");
        let pairs: BTreeMap<_, _> = built.url.query_pairs().into_owned().collect();
        assert_eq!(pairs["query"], "mountains");
        assert_eq!(pairs["content_filter"], "high");
        assert!(!pairs.contains_key("page"));
        let parsed = UnsplashPlugin
            .parse_random_response(
                &req,
                HostHttpResponse {
                    status: 200,
                    content_type: None,
                    body: include_bytes!("../tests/fixtures/search.json").to_vec(),
                },
            )
            .unwrap();
        assert!(parsed.next_cursor.unwrap().starts_with("random:"));

        req.query = Some("https://unsplash.com/collections/123/nature".into());
        let built = UnsplashPlugin.build_random_request(&req).unwrap();
        let pairs: BTreeMap<_, _> = built.url.query_pairs().into_owned().collect();
        assert_eq!(pairs["collections"], "123");
        assert!(!pairs.contains_key("query"));
    }

    #[test]
    fn parses_photo_and_preserves_download_tracking_url() {
        let body = include_bytes!("../tests/fixtures/search.json");
        let page = UnsplashPlugin
            .parse_list_response(
                &request(),
                HostHttpResponse {
                    status: 200,
                    content_type: Some("application/json".into()),
                    body: body.to_vec(),
                },
            )
            .unwrap();
        assert_eq!(page.next_cursor.as_deref(), Some("2"));
        assert_eq!(page.items[0].author.as_ref().unwrap().name, "Ada");
        assert!(
            page.items[0]
                .metadata
                .contains_key("unsplash.download_location")
        );
    }

    #[test]
    fn handles_empty_search_and_http_error() {
        let empty = UnsplashPlugin
            .parse_list_response(
                &request(),
                HostHttpResponse {
                    status: 200,
                    content_type: Some("application/json".into()),
                    body: br#"{"total_pages":0,"results":[]}"#.to_vec(),
                },
            )
            .unwrap();
        assert!(empty.items.is_empty());
        assert!(matches!(
            UnsplashPlugin.parse_list_response(
                &request(),
                HostHttpResponse {
                    status: 403,
                    content_type: None,
                    body: Vec::new(),
                }
            ),
            Err(PluginError::HttpStatus(403))
        ));
    }
}
