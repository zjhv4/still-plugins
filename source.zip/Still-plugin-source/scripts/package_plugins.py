#!/usr/bin/env python3
"""Build independently installable, portable no-WASI source packages."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import tempfile
from pathlib import Path

from plugin_common import PLUGINS, PLUGIN_ID, ROOT, load, plugin_directory

TARGET = "wasm32-unknown-unknown"


def write_catalog(output_root: Path) -> Path:
    """A static HTTPS directory is an update channel, including GitHub Pages."""
    entries = []
    for manifest_path in sorted(output_root.glob("*/plugin.toml")):
        manifest = load(manifest_path)
        entries.append({
            "id": manifest["id"],
            "version": manifest["version"],
            "files": {
                name: hashlib.sha256((manifest_path.parent / name).read_bytes()).hexdigest()
                for name in ("plugin.toml", "plugin.wasm", "logo.png", "README.md")
            },
        })
    path = output_root / "catalog.json"
    temporary = output_root / ".catalog.json.tmp"
    temporary.write_text(json.dumps({"schema_version": 1, "plugins": entries},
                                   ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)
    return path


def package_plugin(
    directory: Path,
    output_root: Path,
    cargo_env: dict[str, str],
    *,
    build: bool,
) -> Path:
    cargo = load(directory / "Cargo.toml")
    manifest = load(directory / "plugin.toml")
    crate_name = cargo["package"]["name"]
    plugin_id = manifest["id"]
    if not isinstance(plugin_id, str) or not PLUGIN_ID.fullmatch(plugin_id):
        raise SystemExit(f"{directory.name}: invalid plugin id")
    destination = output_root / plugin_id
    if destination.is_symlink():
        raise SystemExit(f"refusing to replace a symlink: {destination}")
    backup = output_root / f".{plugin_id}.previous"
    if backup.exists() or backup.is_symlink():
        raise SystemExit(f"recover the interrupted package before retrying: {backup}")
    if build:
        subprocess.run(
            [
                "cargo",
                "build",
                "--release",
                "--target",
                TARGET,
                "-p",
                crate_name,
            ],
            cwd=ROOT,
            check=True,
            env=cargo_env,
        )
    artifact = (
        ROOT
        / "target"
        / TARGET
        / "release"
        / f"{crate_name.replace('-', '_')}.wasm"
    )
    if not artifact.is_file():
        raise SystemExit(f"missing Wasm artifact: {artifact}")

    module_checksum = hashlib.sha256(artifact.read_bytes()).hexdigest()
    logo_relative = Path(manifest["logo"])
    if logo_relative.is_absolute() or ".." in logo_relative.parts:
        raise SystemExit(f"{directory.name}: logo must stay inside its package")
    logo_source = directory / logo_relative
    if not logo_source.is_file():
        raise SystemExit(f"{directory.name}: missing logo {logo_relative}")
    logo_checksum = hashlib.sha256(logo_source.read_bytes()).hexdigest()
    metadata = (directory / "plugin.toml").read_text(encoding="utf-8")
    lines = [
        line
        for line in metadata.splitlines()
        if not line.startswith(("module_sha256 =", "logo_sha256 ="))
    ]
    module_index = next(
        (index for index, line in enumerate(lines) if line.startswith("module =")), None
    )
    if module_index is None:
        raise SystemExit(f"{directory.name}: plugin.toml does not declare module")
    lines.insert(module_index + 1, f'module_sha256 = "{module_checksum}"')
    logo_index = next(
        (index for index, line in enumerate(lines) if line.startswith("logo =")), None
    )
    if logo_index is None:
        raise SystemExit(f"{directory.name}: plugin.toml does not declare logo")
    lines.insert(logo_index + 1, f'logo_sha256 = "{logo_checksum}"')
    output_root.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix=".package-", dir=output_root) as temporary:
        staging = Path(temporary) / "package"
        staging.mkdir()
        shutil.copyfile(artifact, staging / "plugin.wasm")
        logo = staging / logo_relative
        logo.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(logo_source, logo)
        (staging / "plugin.toml").write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
        shutil.copyfile(directory / "README.md", staging / "README.md")
        if destination.exists():
            destination.rename(backup)
        try:
            staging.rename(destination)
        except OSError:
            if backup.exists():
                backup.rename(destination)
            raise
        if backup.exists():
            shutil.rmtree(backup)
    return destination


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "plugins",
        nargs="*",
        help="plugin directory names; omit to package every source",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=ROOT / "dist" / "plugins",
        help="package output directory (default: dist/plugins)",
    )
    parser.add_argument(
        "--target-sysroot",
        type=Path,
        help="optional wasm32 sysroot path; useful for a temporary distro target package",
    )
    parser.add_argument(
        "--skip-build",
        action="store_true",
        help="reuse existing target/wasm32-unknown-unknown/release artifacts",
    )
    args = parser.parse_args()
    names = args.plugins or [
        path.name
        for path in sorted(PLUGINS.iterdir())
        if not path.name.startswith("_") and (path / "Cargo.toml").is_file()
    ]
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    cargo_env = os.environ.copy()
    if args.target_sysroot:
        key = "CARGO_TARGET_WASM32_UNKNOWN_UNKNOWN_RUSTFLAGS"
        existing = cargo_env.get(key, "").strip()
        flag = f"--sysroot={args.target_sysroot.resolve()}"
        cargo_env[key] = f"{existing} {flag}".strip()
    for name in names:
        directory = plugin_directory(name)
        destination = package_plugin(
            directory,
            output,
            cargo_env,
            build=not args.skip_build,
        )
        if name == "image-fit":
            bundled = ROOT / "apps/wallpaper-flutter/assets/bundled-plugins" / load(directory / "plugin.toml")["id"]
            bundled.mkdir(parents=True, exist_ok=True)
            for filename in ("plugin.toml", "plugin.wasm", "logo.png", "README.md"):
                shutil.copyfile(destination / filename, bundled / filename)
        print(f"Packaged {name}: {destination}")
    write_catalog(output)
    write_catalog(ROOT / "apps/wallpaper-flutter/assets/bundled-plugins")


if __name__ == "__main__":
    main()
