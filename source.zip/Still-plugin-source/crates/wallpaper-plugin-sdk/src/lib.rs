mod image_processing;
pub use image_processing::*;

use std::collections::BTreeMap;

use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use thiserror::Error;
use url::Url;

pub const PLUGIN_API_VERSION: &str = "1.4.0";

/// 1.4 adds optional processing descriptors and commands; existing 1.3 source
/// packages keep their wire shape and remain independently installable.
pub fn supports_plugin_api(version: &str) -> bool {
    let parts: Option<Vec<u32>> = version.split('.').map(|part| part.parse().ok()).collect();
    matches!(parts.as_deref(), Some([1, 3, _]) | Some([1, 4, 0]))
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct PluginManifest {
    pub id: String,
    pub name: String,
    pub version: String,
    pub api_version: String,
    pub minimum_client_version: String,
    pub author: String,
    pub description: String,
    pub allowed_hosts: Vec<String>,
    #[serde(default)]
    pub repository_url: Option<Url>,
    #[serde(default)]
    pub documentation_url: Option<Url>,
    #[serde(default = "default_plugin_license")]
    pub license: String,
    #[serde(default)]
    pub update_manifest_url: Option<Url>,
    #[serde(default)]
    pub network: NetworkPolicy,
}

fn default_plugin_license() -> String {
    "MPL-2.0".into()
}

impl PluginManifest {
    pub fn new(
        id: impl Into<String>,
        name: impl Into<String>,
        version: impl Into<String>,
        author: impl Into<String>,
        description: impl Into<String>,
        allowed_hosts: impl IntoIterator<Item = impl Into<String>>,
    ) -> Self {
        Self {
            id: id.into(),
            name: name.into(),
            version: version.into(),
            api_version: PLUGIN_API_VERSION.into(),
            minimum_client_version: "0.1.0".into(),
            author: author.into(),
            description: description.into(),
            allowed_hosts: allowed_hosts.into_iter().map(Into::into).collect(),
            repository_url: None,
            documentation_url: None,
            license: "MPL-2.0".into(),
            update_manifest_url: None,
            network: NetworkPolicy::default(),
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct NetworkPolicy {
    pub requests_per_minute: u16,
    pub max_concurrent_requests: u8,
    pub timeout_seconds: u16,
    pub max_retries: u8,
}

impl Default for NetworkPolicy {
    fn default() -> Self {
        Self {
            requests_per_minute: 30,
            max_concurrent_requests: 2,
            timeout_seconds: 20,
            max_retries: 2,
        }
    }
}

#[derive(Debug, Clone, Default, PartialEq, Eq, Serialize, Deserialize)]
pub struct SourceCapabilities {
    pub list: bool,
    pub search: bool,
    pub random: bool,
    pub resolve: bool,
    /// Requests the host's portable local-folder scanner capability. The
    /// plugin still receives no filesystem access of its own.
    #[serde(default)]
    pub local_folders: bool,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ConfigSchema {
    pub version: u32,
    pub fields: Vec<ConfigField>,
}

impl Default for ConfigSchema {
    fn default() -> Self {
        Self {
            version: 1,
            fields: Vec::new(),
        }
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ConfigField {
    pub key: String,
    pub label: String,
    pub description: Option<String>,
    pub required: bool,
    pub sensitive: bool,
    #[serde(flatten)]
    pub kind: ConfigFieldKind,
}

/// Declarative presentation hints owned by the plugin. The host remains in
/// control of rendering and secret storage, while community plugins decide
/// which configuration entries appear directly on their source card.
#[derive(Debug, Clone, Default, PartialEq, Eq, Serialize, Deserialize)]
pub struct ConfigUiSchema {
    #[serde(default)]
    pub card: Vec<CardConfigItem>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct CardConfigItem {
    pub field_key: String,
    #[serde(default)]
    pub width: CardFieldWidth,
}

impl CardConfigItem {
    pub fn new(field_key: impl Into<String>, width: CardFieldWidth) -> Self {
        Self {
            field_key: field_key.into(),
            width,
        }
    }
}

#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum CardFieldWidth {
    #[default]
    Full,
    Half,
    Third,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum ConfigFieldKind {
    Text { default: Option<String> },
    Url { default: Option<Url> },
    Number { default: Option<f64> },
    Toggle { default: bool },
    Select { options: Vec<SelectOption> },
    MultiSelect { options: Vec<SelectOption> },
    Color,
    Resolution,
    AspectRatio,
    SecretReference,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct SelectOption {
    pub value: String,
    pub label: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct SourceRequest {
    #[serde(default)]
    pub context: SourceExecutionContext,
    pub config: BTreeMap<String, serde_json::Value>,
    pub query: Option<String>,
    pub cursor: Option<String>,
    pub limit: u16,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct SourceExecutionContext {
    pub requested_at: DateTime<Utc>,
    pub random_seed: u64,
}

impl Default for SourceExecutionContext {
    fn default() -> Self {
        Self {
            requested_at: DateTime::<Utc>::UNIX_EPOCH,
            random_seed: 0,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct HostHttpRequest {
    pub method: HttpMethod,
    pub url: Url,
    pub headers: BTreeMap<String, String>,
    #[serde(default)]
    pub form_fields: BTreeMap<String, String>,
    pub max_response_bytes: u64,
    #[serde(default)]
    pub network_scope: NetworkScope,
    #[serde(default)]
    pub credential_injections: Vec<CredentialInjection>,
}

#[derive(Debug, Clone, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum NetworkScope {
    #[default]
    DeclaredHost,
    ConfiguredUrl {
        config_key: String,
    },
    SubdomainOf {
        parent: String,
    },
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct CredentialInjection {
    pub config_key: String,
    pub target: CredentialTarget,
    pub required: bool,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum CredentialTarget {
    Header { name: String, prefix: String },
    Query { name: String },
    Form { name: String },
    BasicPassword { username_config_key: String },
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "UPPERCASE")]
pub enum HttpMethod {
    Get,
    Post,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct AuthorizationDescriptor {
    /// Config key containing the database reference for the short-lived value.
    pub access_credential_key: String,
    /// Refresh this many seconds before expiry.
    pub refresh_before_seconds: u32,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct CredentialRefresh {
    pub access_token: String,
    pub expires_in_seconds: u64,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct HostHttpResponse {
    pub status: u16,
    pub content_type: Option<String>,
    pub body: Vec<u8>,
}

/// Versioned, JSON-encoded ABI between the portable host and an isolated
/// source module. Modules receive no WASI imports; all I/O remains a host
/// capability represented by these messages.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(tag = "command", rename_all = "snake_case")]
pub enum PluginCommand {
    Describe,
    PlanImage {
        request: ImageProcessingRequest,
    },
    ValidateConfig {
        config: BTreeMap<String, serde_json::Value>,
    },
    MigrateConfig {
        from_version: u32,
        config: BTreeMap<String, serde_json::Value>,
    },
    BuildRequest {
        operation: PluginOperation,
        request: SourceRequest,
    },
    ParseResponse {
        operation: PluginOperation,
        request: SourceRequest,
        response: HostHttpResponse,
    },
    BuildDownloadEvent {
        item: Box<WallpaperItem>,
        config: BTreeMap<String, serde_json::Value>,
    },
    BuildAuthorizationRefresh {
        config: BTreeMap<String, serde_json::Value>,
    },
    ParseAuthorizationRefresh {
        response: HostHttpResponse,
    },
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum PluginOperation {
    List,
    Search,
    Random,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct PluginDescription {
    #[serde(default)]
    pub image_processor: Option<ImageProcessorDescription>,
    pub manifest: PluginManifest,
    pub config_schema: ConfigSchema,
    pub config_ui_schema: ConfigUiSchema,
    #[serde(default)]
    pub content_schema: ConfigSchema,
    #[serde(default)]
    pub content_ui_schema: ConfigUiSchema,
    #[serde(default)]
    pub authorization: Option<AuthorizationDescriptor>,
    pub capabilities: SourceCapabilities,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct PluginWireResponse {
    pub ok: bool,
    #[serde(
        default,
        skip_serializing_if = "Option::is_none",
        deserialize_with = "present_response_value"
    )]
    pub value: Option<serde_json::Value>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub error: Option<String>,
}

fn present_response_value<'de, D: serde::Deserializer<'de>>(
    deserializer: D,
) -> Result<Option<serde_json::Value>, D::Error> {
    // `null` is a valid result for validation and optional capability commands.
    // Keep it distinct from an omitted field, which is a protocol violation.
    serde_json::Value::deserialize(deserializer).map(Some)
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct WallpaperPage {
    pub items: Vec<WallpaperItem>,
    pub next_cursor: Option<String>,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct WallpaperItem {
    pub id: String,
    pub title: Option<String>,
    pub description: Option<String>,
    pub author: Option<Author>,
    pub source_page_url: Url,
    pub license: Option<License>,
    pub attribution: Option<String>,
    pub published_at: Option<DateTime<Utc>>,
    pub tags: Vec<String>,
    pub content_rating: ContentRating,
    pub location: Option<Location>,
    pub variants: Vec<WallpaperVariant>,
    pub metadata: BTreeMap<String, serde_json::Value>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct Author {
    pub name: String,
    pub url: Option<Url>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct License {
    pub name: String,
    pub url: Option<Url>,
}

#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ContentRating {
    #[default]
    Safe,
    Sketchy,
    Adult,
    Unknown,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct Location {
    pub country: Option<String>,
    pub region: Option<String>,
    pub latitude: Option<f64>,
    pub longitude: Option<f64>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct WallpaperVariant {
    pub url: Url,
    pub mime_type: Option<String>,
    pub width: Option<u32>,
    pub height: Option<u32>,
    pub file_size: Option<u64>,
    pub checksum: Option<String>,
}

#[derive(Debug, Error)]
pub enum PluginError {
    #[error("invalid configuration: {0}")]
    InvalidConfig(String),
    #[error("source response could not be parsed: {0}")]
    InvalidResponse(String),
    #[error("source returned HTTP status {0}")]
    HttpStatus(u16),
    #[error("source operation is not supported")]
    Unsupported,
    #[error("configuration schema {0} cannot be migrated")]
    UnsupportedConfigVersion(u32),
}

pub trait Plugin: Send + Sync {
    fn image_processor(&self) -> Option<ImageProcessorDescription> {
        None
    }
    fn plan_image(
        &self,
        _request: &ImageProcessingRequest,
    ) -> Result<ImageRenderPlan, PluginError> {
        Err(PluginError::Unsupported)
    }
    fn manifest(&self) -> PluginManifest;
    fn config_schema(&self) -> ConfigSchema;
    fn config_ui_schema(&self) -> ConfigUiSchema {
        ConfigUiSchema::default()
    }
    /// Schema for repeatable content definitions inside one configured source
    /// instance (for example several searches or several feed URLs).
    fn content_schema(&self) -> ConfigSchema {
        let mut schema = self.config_schema();
        schema.fields.retain(|field| !field.sensitive);
        schema
    }
    fn content_ui_schema(&self) -> ConfigUiSchema {
        let keys: std::collections::HashSet<_> = self
            .content_schema()
            .fields
            .into_iter()
            .map(|field| field.key)
            .collect();
        ConfigUiSchema {
            card: self
                .config_ui_schema()
                .card
                .into_iter()
                .filter(|item| keys.contains(&item.field_key))
                .collect(),
        }
    }
    fn authorization(&self) -> Option<AuthorizationDescriptor> {
        None
    }
    fn capabilities(&self) -> SourceCapabilities;
    fn validate_config(
        &self,
        config: &BTreeMap<String, serde_json::Value>,
    ) -> Result<(), PluginError>;
    fn migrate_config(
        &self,
        from_version: u32,
        config: BTreeMap<String, serde_json::Value>,
    ) -> Result<BTreeMap<String, serde_json::Value>, PluginError> {
        if from_version == self.config_schema().version {
            self.validate_config(&config)?;
            Ok(config)
        } else {
            Err(PluginError::UnsupportedConfigVersion(from_version))
        }
    }
    fn build_list_request(&self, _request: &SourceRequest) -> Result<HostHttpRequest, PluginError> {
        Err(PluginError::Unsupported)
    }
    fn parse_list_response(
        &self,
        _request: &SourceRequest,
        _response: HostHttpResponse,
    ) -> Result<WallpaperPage, PluginError> {
        Err(PluginError::Unsupported)
    }
    fn build_search_request(
        &self,
        _request: &SourceRequest,
    ) -> Result<HostHttpRequest, PluginError> {
        Err(PluginError::Unsupported)
    }
    fn parse_search_response(
        &self,
        _request: &SourceRequest,
        _response: HostHttpResponse,
    ) -> Result<WallpaperPage, PluginError> {
        Err(PluginError::Unsupported)
    }
    fn build_random_request(
        &self,
        _request: &SourceRequest,
    ) -> Result<HostHttpRequest, PluginError> {
        Err(PluginError::Unsupported)
    }
    fn parse_random_response(
        &self,
        _request: &SourceRequest,
        _response: HostHttpResponse,
    ) -> Result<WallpaperPage, PluginError> {
        Err(PluginError::Unsupported)
    }

    /// Optional provider callback that must be executed when an item is
    /// downloaded. Providers such as Unsplash use this for API-compliant
    /// download tracking. The host applies the same network and credential
    /// policy as it does for discovery requests.
    fn build_download_event_request(
        &self,
        _item: &WallpaperItem,
        _config: &BTreeMap<String, serde_json::Value>,
    ) -> Result<Option<HostHttpRequest>, PluginError> {
        Ok(None)
    }
    fn build_authorization_refresh_request(
        &self,
        _config: &BTreeMap<String, serde_json::Value>,
    ) -> Result<Option<HostHttpRequest>, PluginError> {
        Ok(None)
    }
    fn parse_authorization_refresh_response(
        &self,
        _response: HostHttpResponse,
    ) -> Result<CredentialRefresh, PluginError> {
        Err(PluginError::Unsupported)
    }
}

/// Compatibility name for source plugin authors.
pub use Plugin as SourcePlugin;

pub fn dispatch_plugin_command(plugin: &dyn SourcePlugin, input: &[u8]) -> Vec<u8> {
    let result = serde_json::from_slice::<PluginCommand>(input)
        .map_err(|error| format!("invalid plugin command: {error}"))
        .and_then(|command| dispatch_decoded_command(plugin, command));
    let response = match result {
        Ok(value) => PluginWireResponse {
            ok: true,
            value: Some(value),
            error: None,
        },
        Err(error) => PluginWireResponse {
            ok: false,
            value: None,
            error: Some(error),
        },
    };
    serde_json::to_vec(&response).unwrap_or_else(|error| {
        format!(r#"{{"ok":false,"error":"wire serialization failed: {error}"}}"#).into_bytes()
    })
}

fn dispatch_decoded_command(
    plugin: &dyn SourcePlugin,
    command: PluginCommand,
) -> Result<serde_json::Value, String> {
    let value = match command {
        PluginCommand::Describe => serde_json::to_value(PluginDescription {
            manifest: plugin.manifest(),
            image_processor: plugin.image_processor(),
            config_schema: plugin.config_schema(),
            config_ui_schema: plugin.config_ui_schema(),
            content_schema: plugin.content_schema(),
            content_ui_schema: plugin.content_ui_schema(),
            authorization: plugin.authorization(),
            capabilities: plugin.capabilities(),
        })
        .map_err(|error| error.to_string()),
        PluginCommand::PlanImage { request } => plugin
            .plan_image(&request)
            .and_then(|plan| {
                serde_json::to_value(plan)
                    .map_err(|error| PluginError::InvalidResponse(error.to_string()))
            })
            .map_err(|error| error.to_string()),
        PluginCommand::ValidateConfig { config } => plugin
            .validate_config(&config)
            .map(|()| serde_json::Value::Null)
            .map_err(|error| error.to_string()),
        PluginCommand::MigrateConfig {
            from_version,
            config,
        } => plugin
            .migrate_config(from_version, config)
            .and_then(|value| {
                serde_json::to_value(value)
                    .map_err(|error| PluginError::InvalidResponse(error.to_string()))
            })
            .map_err(|error| error.to_string()),
        PluginCommand::BuildRequest { operation, request } => match operation {
            PluginOperation::List => plugin.build_list_request(&request),
            PluginOperation::Search => plugin.build_search_request(&request),
            PluginOperation::Random => plugin.build_random_request(&request),
        }
        .and_then(|value| {
            serde_json::to_value(value)
                .map_err(|error| PluginError::InvalidResponse(error.to_string()))
        })
        .map_err(|error| error.to_string()),
        PluginCommand::ParseResponse {
            operation,
            request,
            response,
        } => match operation {
            PluginOperation::List => plugin.parse_list_response(&request, response),
            PluginOperation::Search => plugin.parse_search_response(&request, response),
            PluginOperation::Random => plugin.parse_random_response(&request, response),
        }
        .and_then(|value| {
            serde_json::to_value(value)
                .map_err(|error| PluginError::InvalidResponse(error.to_string()))
        })
        .map_err(|error| error.to_string()),
        PluginCommand::BuildDownloadEvent { item, config } => plugin
            .build_download_event_request(&item, &config)
            .and_then(|value| {
                serde_json::to_value(value)
                    .map_err(|error| PluginError::InvalidResponse(error.to_string()))
            })
            .map_err(|error| error.to_string()),
        PluginCommand::BuildAuthorizationRefresh { config } => plugin
            .build_authorization_refresh_request(&config)
            .and_then(|value| {
                serde_json::to_value(value)
                    .map_err(|error| PluginError::InvalidResponse(error.to_string()))
            })
            .map_err(|error| error.to_string()),
        PluginCommand::ParseAuthorizationRefresh { response } => plugin
            .parse_authorization_refresh_response(response)
            .and_then(|value| {
                serde_json::to_value(value)
                    .map_err(|error| PluginError::InvalidResponse(error.to_string()))
            })
            .map_err(|error| error.to_string()),
    }?;
    Ok(value)
}

/// Exports the small allocation/run/free ABI used by the portable Wasm host.
/// Invoke this macro exactly once from a source crate for `wasm32` builds.
#[macro_export]
macro_rules! export_source_plugin {
    ($plugin:expr) => {
        #[unsafe(no_mangle)]
        pub extern "C" fn wallpaper_plugin_alloc(length: u32) -> u32 {
            let buffer = vec![0_u8; length as usize].into_boxed_slice();
            Box::into_raw(buffer) as *mut u8 as u32
        }

        #[unsafe(no_mangle)]
        pub extern "C" fn wallpaper_plugin_run(pointer: u32, length: u32) -> u64 {
            let input_pointer =
                std::ptr::slice_from_raw_parts_mut(pointer as *mut u8, length as usize);
            let input = unsafe { Box::from_raw(input_pointer) };
            let output = $crate::dispatch_plugin_command(&$plugin, &input).into_boxed_slice();
            let output_length = output.len() as u32;
            let output_pointer = Box::into_raw(output) as *mut u8 as u32;
            (u64::from(output_pointer) << 32) | u64::from(output_length)
        }

        #[unsafe(no_mangle)]
        pub extern "C" fn wallpaper_plugin_free(pointer: u32, length: u32) {
            if length > 0 {
                let slice = std::ptr::slice_from_raw_parts_mut(pointer as *mut u8, length as usize);
                unsafe {
                    drop(Box::from_raw(slice));
                }
            }
        }
    };
}

pub fn host_is_allowed(manifest: &PluginManifest, request: &HostHttpRequest) -> bool {
    request.url.scheme() == "https"
        && matches!(request.network_scope, NetworkScope::DeclaredHost)
        && request
            .url
            .host_str()
            .is_some_and(|host| manifest.allowed_hosts.iter().any(|allowed| allowed == host))
}

pub fn request_is_allowed(
    manifest: &PluginManifest,
    request: &HostHttpRequest,
    config: &BTreeMap<String, serde_json::Value>,
) -> bool {
    if request.url.scheme() != "https" {
        return false;
    }
    match &request.network_scope {
        NetworkScope::DeclaredHost => request
            .url
            .host_str()
            .is_some_and(|host| manifest.allowed_hosts.iter().any(|allowed| allowed == host)),
        NetworkScope::ConfiguredUrl { config_key } => config
            .get(config_key)
            .and_then(serde_json::Value::as_str)
            .and_then(|value| Url::parse(value).ok())
            .is_some_and(|configured| {
                configured.scheme() == "https"
                    && configured.host_str() == request.url.host_str()
                    && configured.port_or_known_default() == request.url.port_or_known_default()
            }),
        NetworkScope::SubdomainOf { parent } => request.url.host_str().is_some_and(|host| {
            host == parent
                || host
                    .strip_suffix(parent)
                    .is_some_and(|prefix| prefix.ends_with('.'))
        }),
    }
}

pub fn ensure_success(response: &HostHttpResponse) -> Result<(), PluginError> {
    if (200..300).contains(&response.status) {
        Ok(())
    } else {
        Err(PluginError::HttpStatus(response.status))
    }
}

pub fn config_string<'a>(
    config: &'a BTreeMap<String, serde_json::Value>,
    key: &str,
) -> Result<&'a str, PluginError> {
    config
        .get(key)
        .and_then(serde_json::Value::as_str)
        .filter(|value| !value.trim().is_empty())
        .ok_or_else(|| PluginError::InvalidConfig(format!("{key} is required")))
}

pub fn optional_config_string<'a>(
    config: &'a BTreeMap<String, serde_json::Value>,
    key: &str,
) -> Option<&'a str> {
    config
        .get(key)
        .and_then(serde_json::Value::as_str)
        .filter(|value| !value.trim().is_empty())
}

/// Page a bounded provider catalog without silently discarding its tail.
pub fn paginate_items(
    items: Vec<WallpaperItem>,
    request: &SourceRequest,
) -> Result<WallpaperPage, PluginError> {
    let page = page_number(request.cursor.as_deref())?;
    let limit = usize::from(request.limit.max(1));
    let start = usize::try_from(page - 1)
        .ok()
        .and_then(|value| value.checked_mul(limit))
        .ok_or_else(|| PluginError::InvalidConfig("page offset is too large".into()))?;
    let next_cursor = (items.len() > start.saturating_add(limit)).then(|| (page + 1).to_string());
    Ok(WallpaperPage {
        items: items.into_iter().skip(start).take(limit).collect(),
        next_cursor,
    })
}

pub fn page_number(cursor: Option<&str>) -> Result<u32, PluginError> {
    cursor
        .unwrap_or("1")
        .parse::<u32>()
        .ok()
        .filter(|page| *page > 0)
        .ok_or_else(|| PluginError::InvalidConfig("cursor must be a positive page number".into()))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn network_policy_requires_https_and_declared_host() {
        let manifest = PluginManifest {
            id: "test".into(),
            name: "Test".into(),
            version: "1.0.0".into(),
            api_version: PLUGIN_API_VERSION.into(),
            minimum_client_version: "0.1.0".into(),
            author: "Test".into(),
            description: String::new(),
            allowed_hosts: vec!["example.com".into()],
            repository_url: None,
            documentation_url: None,
            license: "MPL-2.0".into(),
            update_manifest_url: None,
            network: NetworkPolicy::default(),
        };
        let request = HostHttpRequest {
            method: HttpMethod::Get,
            url: Url::parse("https://example.com/feed").unwrap(),
            headers: BTreeMap::new(),
            form_fields: BTreeMap::new(),
            max_response_bytes: 1024,
            network_scope: NetworkScope::DeclaredHost,
            credential_injections: Vec::new(),
        };
        assert!(host_is_allowed(&manifest, &request));

        let mut insecure = request.clone();
        insecure.url = Url::parse("http://example.com/feed").unwrap();
        assert!(!host_is_allowed(&manifest, &insecure));
    }

    #[test]
    fn configured_url_scope_allows_only_the_configured_origin() {
        let manifest =
            PluginManifest::new("test", "Test", "1.0.0", "Test", "", Vec::<String>::new());
        let config = BTreeMap::from([(
            "feed_url".into(),
            serde_json::json!("https://feeds.example.com/pictures.xml"),
        )]);
        let request = HostHttpRequest {
            method: HttpMethod::Get,
            url: Url::parse("https://feeds.example.com/next.xml").unwrap(),
            headers: BTreeMap::new(),
            form_fields: BTreeMap::new(),
            max_response_bytes: 1024,
            network_scope: NetworkScope::ConfiguredUrl {
                config_key: "feed_url".into(),
            },
            credential_injections: Vec::new(),
        };

        assert!(request_is_allowed(&manifest, &request, &config));
        let mut escaped = request;
        escaped.url = Url::parse("https://tracker.example.net/pixel").unwrap();
        assert!(!request_is_allowed(&manifest, &escaped, &config));
    }

    #[test]
    fn subdomain_scope_does_not_allow_lookalike_domains() {
        let manifest =
            PluginManifest::new("test", "Test", "1.0.0", "Test", "", Vec::<String>::new());
        let mut request = HostHttpRequest {
            method: HttpMethod::Get,
            url: Url::parse("https://artist.artstation.com/rss").unwrap(),
            headers: BTreeMap::new(),
            form_fields: BTreeMap::new(),
            max_response_bytes: 1024,
            network_scope: NetworkScope::SubdomainOf {
                parent: "artstation.com".into(),
            },
            credential_injections: Vec::new(),
        };
        assert!(request_is_allowed(&manifest, &request, &BTreeMap::new()));
        request.url = Url::parse("https://artstation.com.attacker.example/rss").unwrap();
        assert!(!request_is_allowed(&manifest, &request, &BTreeMap::new()));
    }

    #[test]
    fn successful_null_response_is_distinct_from_a_missing_result() {
        let response: PluginWireResponse =
            serde_json::from_str(r#"{"ok":true,"value":null}"#).unwrap();
        assert_eq!(response.value, Some(serde_json::Value::Null));
        let response: PluginWireResponse = serde_json::from_str(r#"{"ok":true}"#).unwrap();
        assert_eq!(response.value, None);
    }

    #[test]
    fn version_1_manifest_deserializes_with_safe_defaults() {
        let old = serde_json::json!({
            "id": "org.wallpaper.source.old",
            "name": "Old",
            "version": "1.0.0",
            "api_version": "1.0.0",
            "minimum_client_version": "0.1.0",
            "author": "Community",
            "description": "Old manifest",
            "allowed_hosts": ["example.com"]
        });
        let manifest: PluginManifest = serde_json::from_value(old).unwrap();
        assert_eq!(manifest.license, "MPL-2.0");
        assert_eq!(manifest.network, NetworkPolicy::default());
        assert!(manifest.update_manifest_url.is_none());
    }
}
